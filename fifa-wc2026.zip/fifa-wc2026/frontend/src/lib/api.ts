const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    throw new Error(`API error: ${res.status} ${res.statusText}`);
  }
  return res.json();
}

export const api = {
  // Predictions
  getTournamentPredictions: () =>
    apiFetch<{ predictions: TeamPrediction[] }>('/api/v1/predictions/tournament'),

  predictMatch: (homeTeam: string, awayTeam: string, neutral = true) =>
    apiFetch<MatchPrediction>('/api/v1/predictions/match', {
      method: 'POST',
      body: JSON.stringify({ home_team: homeTeam, away_team: awayTeam, neutral }),
    }),

  getTeamNames: () =>
    apiFetch<{ teams: string[] }>('/api/v1/predictions/teams'),

  // Tournament
  simulateTournament: (nSimulations: number) =>
    apiFetch<SimulationResult>('/api/v1/tournament/simulate', {
      method: 'POST',
      body: JSON.stringify({ n_simulations: nSimulations }),
    }),

  getGroups: () =>
    apiFetch<{ groups: Record<string, GroupTeam[]> }>('/api/v1/tournament/groups'),

  // Teams
  getAllTeams: () =>
    apiFetch<{ teams: TeamData[] }>('/api/v1/teams/'),

  getTeam: (name: string) =>
    apiFetch<{ team: TeamData; players: PlayerData[] }>(`/api/v1/teams/${encodeURIComponent(name)}`),

  // Players
  getAllPlayers: () =>
    apiFetch<{ players: PlayerData[]; total: number }>('/api/v1/players/'),

  // Analytics
  getRankings: () =>
    apiFetch<{ rankings: RankingData[] }>('/api/v1/analytics/rankings'),

  compareTeams: (teamA: string, teamB: string) =>
    apiFetch<ComparisonData>(`/api/v1/analytics/comparison/${encodeURIComponent(teamA)}/${encodeURIComponent(teamB)}`),

  getTopStats: () =>
    apiFetch<TopStats>('/api/v1/analytics/top-stats'),

  // Admin
  getAdminStatus: () =>
    apiFetch<AdminStatus>('/api/v1/admin/status'),

  refreshData: () =>
    apiFetch<{ status: string; teams: number }>('/api/v1/admin/refresh', { method: 'POST' }),
};

// Types
export interface TeamPrediction {
  rank: number;
  team: string;
  win_probability: number;
  elo_rating: number;
  fifa_ranking: number;
  squad_value_m: number;
  form_points: number;
  wc_titles: number;
}

export interface MatchPrediction {
  home_team: string;
  away_team: string;
  home_win_prob: number;
  draw_prob: number;
  away_win_prob: number;
  expected_goals_home: number;
  expected_goals_away: number;
  most_likely_score: string;
  confidence: number;
  model_breakdown: Record<string, { win_a: number; draw: number; win_b: number }>;
  explanation: PredictionExplanation;
}

export interface PredictionExplanation {
  favored_team: string;
  win_probability: number;
  factors: ExplanationFactor[];
  summary: string;
}

export interface ExplanationFactor {
  factor: string;
  advantage: string;
  value: string;
  impact: 'high' | 'medium' | 'low';
  icon: string;
}

export interface SimulationResult {
  n_simulations: number;
  results: Record<string, TeamSimResult>;
  top_5: string[];
}

export interface TeamSimResult {
  win_probability: number;
  final_probability: number;
  semi_probability: number;
  quarter_probability: number;
  r16_probability: number;
  group_qualification: number;
  team_name: string;
}

export interface TeamData {
  name: string;
  code: string;
  confederation: string;
  group?: string;
  fifa_ranking: number;
  elo_rating: number;
  squad_value_m: number;
  avg_age: number;
  goals_scored_avg: number;
  goals_conceded_avg: number;
  xg_avg: number;
  xga_avg: number;
  possession_avg: number;
  shots_on_target_avg: number;
  clean_sheets_pct: number;
  form_points: number;
  wc_titles: number;
  wc_appearances: number;
  best_result: string;
  manager_name: string;
  manager_experience_years: number;
}

export interface PlayerData {
  name: string;
  position: string;
  age: number;
  club: string;
  market_value_m: number;
  caps: number;
  goals: number;
  assists: number;
  avg_rating: number;
  goals_per_90: number;
  assists_per_90: number;
  injured: boolean;
  fitness_pct: number;
  is_key_player: boolean;
  team?: string;
}

export interface GroupTeam {
  name: string;
  code: string;
  confederation: string;
  fifa_ranking: number;
  elo_rating: number;
}

export interface RankingData {
  rank: number;
  team: string;
  code: string;
  elo: number;
  fifa_rank: number;
  value: number;
  confederation: string;
}

export interface ComparisonData {
  team_a: string;
  team_b: string;
  comparison: Record<string, { team_a: number; team_b: number }>;
}

export interface TopStats {
  top_elo: { team: string; value: number }[];
  top_value: { team: string; value: number }[];
  top_xg: { team: string; value: number }[];
}

export interface AdminStatus {
  status: string;
  teams_loaded: number;
  models: string[];
  version: string;
}
