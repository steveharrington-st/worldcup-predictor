export const TEAM_FLAGS: Record<string, string> = {
  'Argentina': '🇦🇷', 'France': '🇫🇷', 'Brazil': '🇧🇷', 'England': '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
  'Spain': '🇪🇸', 'Germany': '🇩🇪', 'Portugal': '🇵🇹', 'Netherlands': '🇳🇱',
  'Belgium': '🇧🇪', 'Uruguay': '🇺🇾', 'Croatia': '🇭🇷', 'Italy': '🇮🇹',
  'Morocco': '🇲🇦', 'Senegal': '🇸🇳', 'Japan': '🇯🇵', 'South Korea': '🇰🇷',
  'USA': '🇺🇸', 'Mexico': '🇲🇽', 'Canada': '🇨🇦', 'Australia': '🇦🇺',
  'Colombia': '🇨🇴', 'Iran': '🇮🇷', 'Saudi Arabia': '🇸🇦', 'Ghana': '🇬🇭',
};

export const CONFEDERATION_COLORS: Record<string, string> = {
  'UEFA': '#3B82F6',
  'CONMEBOL': '#10B981',
  'CONCACAF': '#F59E0B',
  'AFC': '#EF4444',
  'CAF': '#8B5CF6',
  'OFC': '#EC4899',
};

export const POSITION_COLORS: Record<string, string> = {
  'GK': '#F59E0B',
  'DEF': '#3B82F6',
  'MID': '#10B981',
  'FWD': '#EF4444',
};

export function getFlag(teamName: string): string {
  return TEAM_FLAGS[teamName] || '🏳️';
}

export function formatProbability(prob: number): string {
  return `${(prob * 100).toFixed(1)}%`;
}

export function formatValue(valueMillion: number): string {
  if (valueMillion >= 1000) return `€${(valueMillion / 1000).toFixed(1)}B`;
  return `€${valueMillion.toFixed(0)}M`;
}

export function getProbabilityColor(prob: number): string {
  if (prob >= 0.6) return '#22C55E';
  if (prob >= 0.45) return '#84CC16';
  if (prob >= 0.35) return '#EAB308';
  if (prob >= 0.25) return '#F97316';
  return '#EF4444';
}

export function getFormColor(result: string): string {
  if (result === 'W') return 'bg-green-500';
  if (result === 'D') return 'bg-yellow-500';
  return 'bg-red-500';
}

export function getRankColor(rank: number): string {
  if (rank === 1) return 'text-gold-400';
  if (rank === 2) return 'text-gray-300';
  if (rank === 3) return 'text-amber-600';
  return 'text-green-400';
}
