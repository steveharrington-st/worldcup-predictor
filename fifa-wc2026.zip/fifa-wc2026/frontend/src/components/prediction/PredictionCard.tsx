'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { TeamPrediction } from '@/lib/api';
import { getFlag, formatValue, getProbabilityColor, getRankColor } from '@/lib/utils';

interface PredictionCardProps {
  team: TeamPrediction;
  rank: number;
}

export default function PredictionCard({ team, rank }: PredictionCardProps) {
  const probColor = getProbabilityColor(team.win_probability / 100);
  const isTop3 = rank <= 3;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: rank * 0.05 }}
      whileHover={{ y: -3, transition: { duration: 0.2 } }}
      className={`glass-card p-5 cursor-pointer group relative overflow-hidden ${isTop3 ? 'border-gold-500/20' : ''}`}
    >
      {/* Top 3 shimmer effect */}
      {isTop3 && (
        <div className="absolute inset-0 bg-gold-gradient opacity-3 pointer-events-none" />
      )}

      {/* Rank badge */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <span className={`font-heading text-3xl ${getRankColor(rank)}`}>#{rank}</span>
          <span className="text-3xl">{getFlag(team.team)}</span>
        </div>
        {team.wc_titles > 0 && (
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-gold-500/15 border border-gold-500/20">
            <span className="text-xs">🏆</span>
            <span className="text-gold-400 text-xs font-mono">{team.wc_titles}×</span>
          </div>
        )}
      </div>

      {/* Team name */}
      <h3 className="font-heading text-2xl text-white tracking-wide mb-1 group-hover:text-gold-300 transition-colors">
        {team.team}
      </h3>

      {/* Win probability */}
      <div className="flex items-baseline gap-1 mb-3">
        <span className="font-heading text-4xl" style={{ color: probColor }}>
          {team.win_probability.toFixed(1)}
        </span>
        <span className="text-sm" style={{ color: probColor }}>%</span>
        <span className="text-green-600 text-xs ml-1 font-mono">WIN PROB</span>
      </div>

      {/* Probability bar */}
      <div className="h-1.5 bg-white/5 rounded-full mb-4 overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: probColor }}
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(100, team.win_probability * 5)}%` }}
          transition={{ duration: 1, delay: rank * 0.05 + 0.3 }}
        />
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="p-2 rounded-lg bg-white/3">
          <div className="text-xs text-green-600 font-mono mb-0.5">ELO</div>
          <div className="text-sm text-green-200 font-semibold">{team.elo_rating}</div>
        </div>
        <div className="p-2 rounded-lg bg-white/3">
          <div className="text-xs text-green-600 font-mono mb-0.5">RANK</div>
          <div className="text-sm text-green-200 font-semibold">#{team.fifa_ranking}</div>
        </div>
        <div className="p-2 rounded-lg bg-white/3">
          <div className="text-xs text-green-600 font-mono mb-0.5">VALUE</div>
          <div className="text-sm text-green-200 font-semibold">{formatValue(team.squad_value_m)}</div>
        </div>
      </div>

      {/* Form dots */}
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/5">
        <span className="text-xs text-green-700 font-mono">FORM</span>
        <div className="flex gap-1">
          {Array.from({ length: 5 }, (_, i) => {
            const formPct = team.form_points / 30;
            const isWin = i < Math.round(formPct * 5 * 0.7);
            const isDraw = !isWin && i < Math.round(formPct * 5 * 0.9);
            return (
              <div
                key={i}
                className={`w-2 h-2 rounded-full ${isWin ? 'bg-green-500' : isDraw ? 'bg-yellow-500' : 'bg-red-500/50'}`}
              />
            );
          })}
        </div>
        <Link
          href={`/teams/${encodeURIComponent(team.team)}`}
          className="text-xs text-green-600 hover:text-green-300 font-mono transition-colors"
        >
          DETAILS →
        </Link>
      </div>
    </motion.div>
  );
}
