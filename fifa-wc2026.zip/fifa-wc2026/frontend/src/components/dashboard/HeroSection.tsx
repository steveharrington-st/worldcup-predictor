'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-pitch-gradient" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gold-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[300px] bg-electric-400/3 rounded-full blur-3xl" />
      
      {/* Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 text-center">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold-500/10 border border-gold-500/20 mb-6"
        >
          <span className="text-gold-400 text-xs font-mono tracking-widest">
            ⚽ FIFA WORLD CUP 2026 · USA · CANADA · MEXICO
          </span>
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="font-heading text-6xl md:text-8xl lg:text-9xl text-white tracking-wider leading-none mb-4"
        >
          WHO WILL
          <br />
          <span className="gold-shimmer">LIFT THE</span>
          <br />
          TROPHY?
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-green-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          Advanced ensemble ML model combining ELO ratings, Poisson goal models, 
          XGBoost, and Monte Carlo simulation to predict the 2026 World Cup.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex flex-wrap items-center justify-center gap-4"
        >
          <Link
            href="/match-predictor"
            className="group flex items-center gap-2 px-6 py-3 rounded-xl bg-gold-gradient text-pitch-950 font-semibold text-sm hover:shadow-gold transition-all duration-300"
          >
            ⚽ Predict a Match
          </Link>
          <Link
            href="/simulator"
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-green-200 font-medium text-sm hover:bg-white/10 hover:border-white/20 transition-all"
          >
            🎲 Run Simulations
          </Link>
          <Link
            href="/teams"
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-electric-400/10 border border-electric-400/20 text-electric-400 font-medium text-sm hover:bg-electric-400/20 transition-all"
          >
            📊 Explore Teams
          </Link>
        </motion.div>

        {/* Stats row */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="flex flex-wrap items-center justify-center gap-8 mt-14 text-center"
        >
          {[
            { value: '48', label: 'Qualified Teams' },
            { value: '104', label: 'Matches Total' },
            { value: '6', label: 'ML Models' },
            { value: '100K', label: 'Simulations' },
          ].map(stat => (
            <div key={stat.label}>
              <div className="font-heading text-4xl text-gold-400">{stat.value}</div>
              <div className="text-xs text-green-600 mt-1 font-mono">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
