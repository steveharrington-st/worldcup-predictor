'use client';

import { motion } from 'framer-motion';

const stats = [
  { icon: '🏆', label: 'Defending Champion', value: 'Argentina' },
  { icon: '📍', label: 'Host Nations', value: 'USA • Canada • Mexico' },
  { icon: '📅', label: 'Tournament', value: 'Jun 11 – Jul 19, 2026' },
  { icon: '⚽', label: 'Teams Qualified', value: '48 Nations' },
  { icon: '🤖', label: 'Model Accuracy', value: '~71% (Historical)' },
  { icon: '📊', label: 'Data Points', value: '50,000+ Matches' },
];

export default function StatsBar() {
  return (
    <div className="border-y border-white/5 bg-pitch-900/50 overflow-hidden">
      <div className="flex">
        {/* Scrolling ticker */}
        <motion.div
          className="flex items-center gap-0 py-0"
          animate={{ x: [0, -100 * stats.length] }}
          transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
          style={{ willChange: 'transform' }}
        >
          {[...stats, ...stats].map((stat, i) => (
            <div
              key={i}
              className="flex items-center gap-3 px-8 py-3 border-r border-white/5 whitespace-nowrap shrink-0"
            >
              <span className="text-lg">{stat.icon}</span>
              <span className="text-green-600 text-xs font-mono">{stat.label}</span>
              <span className="text-green-200 text-sm font-medium">{stat.value}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
