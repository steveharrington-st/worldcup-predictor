import type { Metadata } from 'next';
import './globals.css';
import Navigation from '@/components/ui/Navigation';
import { Providers } from './providers';

export const metadata: Metadata = {
  title: 'FIFA World Cup 2026 | AI Prediction Platform',
  description: 'Advanced machine learning predictions for FIFA World Cup 2026. Win probabilities, match predictions, team analytics.',
  keywords: 'FIFA World Cup 2026, football predictions, AI, machine learning, analytics',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-pitch-950 text-green-50 pitch-pattern">
        <Providers>
          <div className="min-h-screen flex flex-col">
            <Navigation />
            <main className="flex-1">
              {children}
            </main>
            <footer className="border-t border-white/5 py-8 text-center text-sm text-green-700 mt-16">
              <p>⚽ FIFA World Cup 2026 AI Prediction Platform</p>
              <p className="text-xs mt-1 opacity-50">Powered by Ensemble ML · ELO · Poisson Models · Monte Carlo Simulation</p>
            </footer>
          </div>
        </Providers>
      </body>
    </html>
  );
}
