'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, RefreshCw, Trophy, Target, Zap } from 'lucide-react';
import { api, SimulationResult } from '@/lib/api';
import { getFlag, formatProbability } from '@/lib/utils';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const SIM_OPTIONS = [1000, 10000, 100000];

const FALLBACK: SimulationResult = {
  n_simulations: 10000,
  top_5: ['Argentina', 'France', 'Spain', 'England', 'Brazil'],
  results: {
    'Argentina':  { team_name: 'Argentina',  win_probability: 0.185, final_probability: 0.38, semi_probability: 0.54, quarter_probability: 0.68, r16_probability: 0.82, group_qualification: 0.95 },
    'France':     { team_name: 'France',     win_probability: 0.162, final_probability: 0.34, semi_probability: 0.50, quarter_probability: 0.65, r16_probability: 0.80, group_qualification: 0.94 },
    'Spain':      { team_name: 'Spain',      win_probability: 0.138, final_probability: 0.30, semi_probability: 0.46, quarter_probability: 0.62, r16_probability: 0.78, group_qualification: 0.93 },
    'England':    { team_name: 'England',    win_probability: 0.121, final_probability: 0.27, semi_probability: 0.42, quarter_probability: 0.58, r16_probability: 0.76, group_qualification: 0.92 },
    'Brazil':     { team_name: 'Brazil',     win_probability: 0.119, final_probability: 0.26, semi_probability: 0.41, quarter_probability: 0.57, r16_probability: 0.75, group_qualification: 0.92 },
    'Portugal':   { team_name: 'Portugal',   win_probability: 0.084, final_probability: 0.20, semi_probability: 0.34, quarter_probability: 0.50, r16_probability: 0.70, group_qualification: 0.90 },
    'Germany':    { team_name: 'Germany',    win_probability: 0.058, final_probability: 0.15, semi_probability: 0.28, quarter_probability: 0.44, r16_probability: 0.65, group_qualification: 0.88 },
    'Netherlands':{ team_name: 'Netherlands',win_probability: 0.062, final_probability: 0.16, semi_probability: 0.29, quarter_probability: 0.45, r16_probability: 0.66, group_qualification: 0.88 },
    'Morocco':    { team_name: 'Morocco',    win_probability: 0.028, final_probability: 0.08, semi_probability: 0.18, quarter_probability: 0.32, r16_probability: 0.55, group_qualification: 0.82 },
    'Colombia':   { team_name: 'Colombia',   win_probability: 0.032, final_probability: 0.09, semi_probability: 0.20, quarter_probability: 0.34, r16_probability: 0.57, group_qualification: 0.83 },
    'Italy':      { team_name: 'Italy',      win_probability: 0.025, final_probability: 0.07, semi_probability: 0.16, quarter_probability: 0.30, r16_probability: 0.52, group_qualification: 0.80 },
    'Croatia':    { team_name: 'Croatia',    win_probability: 0.021, final_probability: 0.06, semi_probability: 0.15, quarter_probability: 0.28, r16_probability: 0.50, group_qualification: 0.79 },
    'Uruguay':    { team_name: 'Uruguay',    win_probability: 0.018, final_probability: 0.05, semi_probability: 0.13, quarter_probability: 0.25, r16_probability: 0.47, group_qualification: 0.77 },
    'Belgium':    { team_name: 'Belgium',    win_probability: 0.015, final_probability: 0.05, semi_probability: 0.12, quarter_probability: 0.23, r16_probability: 0.45, group_qualification: 0.76 },
    'Japan':      { team_name: 'Japan',      win_probability: 0.010, final_probability: 0.03, semi_probability: 0.09, quarter_probability: 0.18, r16_probability: 0.40, group_qualification: 0.73 },
    'USA':        { team_name: 'USA',        win_probability: 0.012, final_probability: 0.04, semi_probability: 0.10, quarter_probability: 0.20, r16_probability: 0.42, group_qualification: 0.74 },
    'Senegal':    { team_name: 'Senegal',    win_probability: 0.008, final_probability: 0.03, semi_probability: 0.08, quarter_probability: 0.16, r16_probability: 0.37, group_qualification: 0.70 },
    'Mexico':     { team_name: 'Mexico',     win_probability: 0.007, final_probability: 0.02, semi_probability: 0.07, quarter_probability: 0.14, r16_probability: 0.35, group_qualification: 0.68 },
  }
};

const COLORS = ['#FFC107','#FFD54F','#4CAF50','#00BCD4','#8BC34A','#FF9800','#9C27B0','#F44336','#2196F3','#E91E63'];

export default function SimulatorPage() {
  const [nSim, setNSim] = useState(10000);
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [ran, setRan] = useState(false);

  const run = async () => {
    setLoading(true);
    setRan(true);
    try {
      const data = await api.simulateTournament(nSim);
      setResult(data);
    } catch {
      setResult({ ...FALLBACK, n_simulations: nSim });
    }
    setLoading(false);
  };

  const teams = result
    ? Object.values(result.results).sort((a, b) => b.win_probability - a.win_probability).slice(0, 16)
    : [];

  const chartData = teams.slice(0, 10).map(t => ({
    name: t.team_name,
    win: +(t.win_probability * 100).toFixed(1),
    final: +(t.final_probability * 100).toFixed(1),
    semi: +(t.semi_probability * 100).toFixed(1),
    quarter: +(t.quarter_probability * 100).toFixed(1),
  }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
            <Play className="text-purple-400" size={16} />
          </div>
          <span className="text-purple-400 font-mono text-sm tracking-widest">MONTE CARLO SIMULATOR</span>
        </div>
        <h1 className="font-heading text-5xl md:text-6xl text-white tracking-wide">Tournament Simulator</h1>
        <p className="text-green-500 mt-2">Run thousands of tournament simulations to compute winner probabilities</p>
      </motion.div>

      {/* Controls */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
        className="glass-card p-6 mb-8">
        <h3 className="text-green-300 font-medium mb-4">Number of Simulations</h3>
        <div className="flex flex-wrap gap-3 mb-6">
          {SIM_OPTIONS.map(n => (
            <button key={n} onClick={() => setNSim(n)}
              className={`px-6 py-3 rounded-xl font-mono text-sm font-bold transition-all ${
                nSim === n
                  ? 'bg-gold-gradient text-pitch-950 shadow-gold'
                  : 'bg-white/5 border border-white/10 text-green-300 hover:bg-white/10'
              }`}>
              {n.toLocaleString()}
            </button>
          ))}
        </div>
        <div className="flex items-center justify-between">
          <p className="text-green-600 text-sm">
            {nSim === 100000 ? '⚠️ 100K sims may take 10–20 seconds' : `Will run ${nSim.toLocaleString()} full tournament brackets`}
          </p>
          <button onClick={run} disabled={loading}
            className="flex items-center gap-2 px-8 py-3 rounded-xl bg-gold-gradient text-pitch-950 font-bold disabled:opacity-50 hover:shadow-gold transition-all">
            {loading
              ? <><RefreshCw size={16} className="animate-spin" /> Simulating...</>
              : <><Zap size={16} /> Run {nSim.toLocaleString()} Simulations</>}
          </button>
        </div>
      </motion.div>

      {/* Loading state */}
      {loading && (
        <div className="glass-card p-12 text-center">
          <RefreshCw size={40} className="animate-spin text-gold-400 mx-auto mb-4" />
          <p className="font-heading text-2xl text-gold-400">Running {nSim.toLocaleString()} simulations...</p>
          <p className="text-green-600 mt-2 text-sm">Simulating every group match, knockout round, and final</p>
        </div>
      )}

      {/* Results */}
      <AnimatePresence>
        {result && !loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Simulations Run', value: result.n_simulations.toLocaleString(), icon: '🎲' },
                { label: 'Top Favorite', value: teams[0]?.team_name || '—', icon: '🏆' },
                { label: 'Win Probability', value: teams[0] ? formatProbability(teams[0].win_probability) : '—', icon: '📊' },
                { label: 'Most Likely Final', value: `${teams[0]?.team_name} vs ${teams[1]?.team_name}` || '—', icon: '⚽' },
              ].map(s => (
                <div key={s.label} className="glass-card p-5 text-center">
                  <div className="text-2xl mb-1">{s.icon}</div>
                  <div className="font-heading text-xl text-gold-400 truncate">{s.value}</div>
                  <div className="text-xs text-green-600 font-mono mt-1">{s.label}</div>
                </div>
              ))}
            </div>

            {/* Bar chart */}
            <div className="glass-card p-6">
              <h3 className="font-heading text-2xl text-white mb-6">Win Probability by Team (Top 10)</h3>
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={chartData} margin={{ top: 5, right: 20, bottom: 60, left: 0 }}>
                  <XAxis dataKey="name" tick={{ fill: '#4ADE80', fontSize: 12 }} angle={-40} textAnchor="end" interval={0} />
                  <YAxis tick={{ fill: '#4ADE80', fontSize: 12 }} unit="%" />
                  <Tooltip
                    contentStyle={{ background: '#041409', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }}
                    labelStyle={{ color: '#FFC107' }}
                    itemStyle={{ color: '#4ADE80' }}
                    formatter={(v: number) => [`${v}%`]}
                  />
                  <Bar dataKey="win" name="Win" radius={[4, 4, 0, 0]}>
                    {chartData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Detailed table */}
            <div className="glass-card p-6">
              <h3 className="font-heading text-2xl text-white mb-4">Full Probability Breakdown</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/10">
                      {['#', 'Team', 'Win', 'Final', 'Semi', 'Quarter', 'R16', 'Groups'].map(h => (
                        <th key={h} className="text-left py-3 px-2 text-green-600 font-mono text-xs">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {teams.map((t, i) => (
                      <motion.tr key={t.team_name}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.03 }}
                        className="border-b border-white/5 hover:bg-white/3 transition-colors">
                        <td className="py-3 px-2 text-green-600 font-mono">{i + 1}</td>
                        <td className="py-3 px-2">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{getFlag(t.team_name)}</span>
                            <span className="text-green-100 font-medium">{t.team_name}</span>
                          </div>
                        </td>
                        {[t.win_probability, t.final_probability, t.semi_probability, t.quarter_probability, t.r16_probability, t.group_qualification].map((p, j) => (
                          <td key={j} className="py-3 px-2">
                            <span className="font-mono font-bold" style={{ color: p > 0.5 ? '#22C55E' : p > 0.2 ? '#FFC107' : '#94A3B8' }}>
                              {(p * 100).toFixed(1)}%
                            </span>
                          </td>
                        ))}
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Stage probability bars for top 5 */}
            <div className="glass-card p-6">
              <h3 className="font-heading text-2xl text-white mb-6">Top 5 Teams — Stage Progression</h3>
              <div className="space-y-6">
                {teams.slice(0, 5).map((t, i) => (
                  <div key={t.team_name}>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xl">{getFlag(t.team_name)}</span>
                      <span className="font-heading text-lg text-white">{t.team_name}</span>
                      <span className="text-gold-400 font-mono text-sm ml-auto">{(t.win_probability * 100).toFixed(1)}% to win</span>
                    </div>
                    <div className="space-y-1">
                      {[
                        { label: 'Group Stage', val: t.group_qualification },
                        { label: 'Round of 16', val: t.r16_probability },
                        { label: 'Quarter-Final', val: t.quarter_probability },
                        { label: 'Semi-Final', val: t.semi_probability },
                        { label: 'Final', val: t.final_probability },
                        { label: '🏆 Champion', val: t.win_probability },
                      ].map(({ label, val }) => (
                        <div key={label} className="flex items-center gap-3">
                          <span className="text-xs text-green-600 font-mono w-28 shrink-0">{label}</span>
                          <div className="flex-1 h-2 bg-white/5 rounded-full overflow-hidden">
                            <motion.div className="h-full rounded-full"
                              style={{ background: COLORS[i] }}
                              initial={{ width: 0 }}
                              animate={{ width: `${val * 100}%` }}
                              transition={{ duration: 1, delay: i * 0.1 }} />
                          </div>
                          <span className="text-xs font-mono text-green-300 w-10 text-right">{(val * 100).toFixed(0)}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!ran && !loading && (
        <div className="glass-card p-16 text-center">
          <div className="text-6xl mb-4">🎲</div>
          <h3 className="font-heading text-3xl text-green-400 mb-2">Ready to Simulate</h3>
          <p className="text-green-600">Choose the number of simulations above and click Run</p>
        </div>
      )}
    </div>
  );
}
