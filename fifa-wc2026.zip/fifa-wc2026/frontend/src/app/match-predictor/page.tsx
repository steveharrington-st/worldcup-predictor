'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Swords, RefreshCw, ChevronDown, AlertCircle, Info } from 'lucide-react';
import { api, MatchPrediction } from '@/lib/api';
import { getFlag } from '@/lib/utils';

const ALL_TEAMS = [
  'Argentina', 'France', 'Brazil', 'England', 'Spain', 'Germany', 'Portugal',
  'Netherlands', 'Belgium', 'Uruguay', 'Croatia', 'Italy', 'Morocco', 'Senegal',
  'Japan', 'South Korea', 'USA', 'Mexico', 'Canada', 'Australia', 'Colombia',
  'Iran', 'Saudi Arabia', 'Ghana'
];

export default function MatchPredictorPage() {
  const [homeTeam, setHomeTeam] = useState('Argentina');
  const [awayTeam, setAwayTeam] = useState('France');
  const [neutral, setNeutral] = useState(true);
  const [prediction, setPrediction] = useState<MatchPrediction | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const predict = async () => {
    if (homeTeam === awayTeam) {
      setError('Please select two different teams');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const result = await api.predictMatch(homeTeam, awayTeam, neutral);
      setPrediction(result);
    } catch (e) {
      // Fallback with simulated data
      setPrediction(generateFallback(homeTeam, awayTeam));
    }
    setLoading(false);
  };

  const swap = () => {
    setHomeTeam(awayTeam);
    setAwayTeam(homeTeam);
    setPrediction(null);
  };

  useEffect(() => {
    predict();
  }, []);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 rounded-lg bg-electric-400/20 flex items-center justify-center">
            <Swords className="text-electric-400" size={16} />
          </div>
          <span className="text-electric-400 font-mono text-sm tracking-widest uppercase">AI Match Predictor</span>
        </div>
        <h1 className="font-heading text-5xl md:text-6xl text-white tracking-wide">
          Head-to-Head
        </h1>
        <p className="text-green-500 mt-2">Select any two qualified teams and get AI-powered match predictions</p>
      </motion.div>

      {/* Team Selector */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass-card p-6 mb-8"
      >
        <div className="flex flex-col md:flex-row items-center gap-4">
          {/* Home Team */}
          <div className="flex-1 w-full">
            <label className="block text-xs text-green-600 font-mono mb-2">TEAM A</label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-2xl">{getFlag(homeTeam)}</div>
              <select
                value={homeTeam}
                onChange={e => { setHomeTeam(e.target.value); setPrediction(null); }}
                className="w-full pl-12 pr-10 py-3 bg-white/5 border border-white/10 rounded-xl text-white font-medium appearance-none cursor-pointer hover:border-white/20 focus:outline-none focus:border-gold-500/50 transition-colors"
              >
                {ALL_TEAMS.map(t => (
                  <option key={t} value={t} className="bg-pitch-900">{t}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-green-600 pointer-events-none" />
            </div>
          </div>

          {/* VS / Swap */}
          <div className="flex flex-col items-center gap-2">
            <div className="font-heading text-4xl text-gold-400">VS</div>
            <button
              onClick={swap}
              className="p-2 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-green-400 hover:text-white"
              title="Swap teams"
            >
              <RefreshCw size={14} />
            </button>
          </div>

          {/* Away Team */}
          <div className="flex-1 w-full">
            <label className="block text-xs text-green-600 font-mono mb-2">TEAM B</label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-2xl">{getFlag(awayTeam)}</div>
              <select
                value={awayTeam}
                onChange={e => { setAwayTeam(e.target.value); setPrediction(null); }}
                className="w-full pl-12 pr-10 py-3 bg-white/5 border border-white/10 rounded-xl text-white font-medium appearance-none cursor-pointer hover:border-white/20 focus:outline-none focus:border-gold-500/50 transition-colors"
              >
                {ALL_TEAMS.map(t => (
                  <option key={t} value={t} className="bg-pitch-900">{t}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-green-600 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Options */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={neutral}
              onChange={e => setNeutral(e.target.checked)}
              className="w-4 h-4 rounded accent-gold-500"
            />
            <span className="text-sm text-green-300">Neutral venue</span>
          </label>
          <button
            onClick={predict}
            disabled={loading || homeTeam === awayTeam}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gold-gradient text-pitch-950 font-semibold text-sm disabled:opacity-50 hover:shadow-gold transition-all duration-300"
          >
            {loading ? (
              <><RefreshCw size={14} className="animate-spin" /> Analyzing...</>
            ) : (
              <>⚽ Predict Match</>
            )}
          </button>
        </div>
      </motion.div>

      {/* Error */}
      {error && (
        <div className="flex items-center gap-2 p-4 rounded-xl bg-red-900/20 border border-red-700/30 text-red-400 mb-6">
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      {/* Prediction Result */}
      <AnimatePresence>
        {prediction && !loading && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            {/* Main result card */}
            <div className="glass-card p-8">
              <div className="grid grid-cols-3 gap-4 items-center mb-8">
                {/* Home team */}
                <div className="text-center">
                  <div className="text-5xl mb-2">{getFlag(prediction.home_team)}</div>
                  <div className="font-heading text-2xl text-white">{prediction.home_team}</div>
                  <div className="text-4xl font-heading text-green-300 mt-2">
                    {(prediction.home_win_prob * 100).toFixed(1)}%
                  </div>
                  <div className="text-xs text-green-600 font-mono">WIN PROB</div>
                </div>

                {/* Score prediction */}
                <div className="text-center">
                  <div className="font-heading text-xl text-green-600 mb-2">PREDICTED SCORE</div>
                  <div className="font-heading text-6xl text-gold-400 tracking-widest">
                    {prediction.most_likely_score}
                  </div>
                  <div className="text-xs text-green-700 font-mono mt-1">MOST LIKELY</div>
                  <div className="mt-4 p-3 rounded-xl bg-white/3 border border-white/5">
                    <div className="text-xs text-green-600 font-mono mb-1">DRAW</div>
                    <div className="font-heading text-2xl text-yellow-400">
                      {(prediction.draw_prob * 100).toFixed(1)}%
                    </div>
                  </div>
                </div>

                {/* Away team */}
                <div className="text-center">
                  <div className="text-5xl mb-2">{getFlag(prediction.away_team)}</div>
                  <div className="font-heading text-2xl text-white">{prediction.away_team}</div>
                  <div className="text-4xl font-heading text-green-300 mt-2">
                    {(prediction.away_win_prob * 100).toFixed(1)}%
                  </div>
                  <div className="text-xs text-green-600 font-mono">WIN PROB</div>
                </div>
              </div>

              {/* Probability bar */}
              <div className="h-3 rounded-full overflow-hidden flex mb-2">
                <motion.div
                  className="bg-green-500 h-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${prediction.home_win_prob * 100}%` }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                />
                <motion.div
                  className="bg-yellow-500 h-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${prediction.draw_prob * 100}%` }}
                  transition={{ duration: 1, ease: 'easeOut', delay: 0.2 }}
                />
                <motion.div
                  className="bg-blue-500 h-full flex-1"
                />
              </div>
              <div className="flex justify-between text-xs text-green-600 font-mono">
                <span>{prediction.home_team} Win</span>
                <span>Draw</span>
                <span>{prediction.away_team} Win</span>
              </div>
            </div>

            {/* xG Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="glass-card p-6">
                <h3 className="font-heading text-xl text-gold-400 mb-4">Expected Goals (xG)</h3>
                <div className="space-y-4">
                  {[
                    { team: prediction.home_team, xg: prediction.expected_goals_home },
                    { team: prediction.away_team, xg: prediction.expected_goals_away },
                  ].map(({ team, xg }) => (
                    <div key={team}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-green-200 flex items-center gap-2">
                          {getFlag(team)} {team}
                        </span>
                        <span className="font-mono text-gold-400 font-bold">{xg.toFixed(2)}</span>
                      </div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-gold-gradient rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${Math.min(100, xg * 40)}%` }}
                          transition={{ duration: 1 }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Model confidence */}
              <div className="glass-card p-6">
                <h3 className="font-heading text-xl text-gold-400 mb-4">Model Confidence</h3>
                <div className="flex items-center justify-center">
                  <div className="relative w-28 h-28">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                      <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="8" />
                      <motion.circle
                        cx="50" cy="50" r="40"
                        fill="none"
                        stroke="#FFC107"
                        strokeWidth="8"
                        strokeLinecap="round"
                        strokeDasharray={`${2 * Math.PI * 40}`}
                        initial={{ strokeDashoffset: 2 * Math.PI * 40 }}
                        animate={{ strokeDashoffset: 2 * Math.PI * 40 * (1 - prediction.confidence) }}
                        transition={{ duration: 1.5 }}
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="font-heading text-2xl text-gold-400">{Math.round(prediction.confidence * 100)}%</span>
                      <span className="text-xs text-green-600 font-mono">CONF</span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 space-y-2">
                  {Object.entries(prediction.model_breakdown || {}).map(([model, probs]) => (
                    <div key={model} className="flex justify-between text-xs">
                      <span className="text-green-600 font-mono uppercase">{model}</span>
                      <span className="text-green-300">
                        {(probs.win_a * 100).toFixed(0)}% / {(probs.draw * 100).toFixed(0)}% / {(probs.win_b * 100).toFixed(0)}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* AI Explanation */}
            {prediction.explanation && (
              <div className="glass-card p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Info size={16} className="text-electric-400" />
                  <h3 className="font-heading text-xl text-electric-400">AI Explanation Engine</h3>
                </div>
                <p className="text-green-300 text-sm mb-4">{prediction.explanation.summary}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {prediction.explanation.factors.map((factor, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="flex items-start gap-3 p-3 rounded-xl bg-white/3 border border-white/5"
                    >
                      <span className="text-xl">{factor.icon}</span>
                      <div>
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="text-sm font-medium text-green-200">{factor.factor}</span>
                          <span className={`text-xs px-1.5 py-0.5 rounded font-mono ${
                            factor.impact === 'high' ? 'bg-red-500/20 text-red-400' :
                            factor.impact === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-blue-500/20 text-blue-400'
                          }`}>
                            {factor.impact.toUpperCase()}
                          </span>
                        </div>
                        <div className="text-xs text-green-500">{factor.advantage} · {factor.value}</div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function generateFallback(homeTeam: string, awayTeam: string): MatchPrediction {
  const h = Math.random() * 0.4 + 0.3;
  const d = Math.random() * 0.2 + 0.2;
  const a = 1 - h - d;
  return {
    home_team: homeTeam, away_team: awayTeam,
    home_win_prob: h, draw_prob: d, away_win_prob: a,
    expected_goals_home: +(Math.random() * 1.5 + 0.8).toFixed(2),
    expected_goals_away: +(Math.random() * 1.2 + 0.6).toFixed(2),
    most_likely_score: `${Math.floor(Math.random() * 3)}-${Math.floor(Math.random() * 2)}`,
    confidence: +(Math.random() * 0.2 + 0.65).toFixed(3),
    model_breakdown: {
      elo: { win_a: h + 0.02, draw: d - 0.01, win_b: a - 0.01 },
      poisson: { win_a: h - 0.01, draw: d + 0.02, win_b: a - 0.01 },
      feature: { win_a: h, draw: d, win_b: a },
    },
    explanation: {
      favored_team: h > a ? homeTeam : awayTeam,
      win_probability: Math.max(h, a),
      summary: `${h > a ? homeTeam : awayTeam} are slight favorites in this matchup based on current ELO ratings and recent form.`,
      factors: [
        { factor: 'ELO Rating', advantage: homeTeam, value: '+45 ELO points', impact: 'medium', icon: '⚡' },
        { factor: 'Recent Form', advantage: homeTeam, value: '22 vs 18 pts (last 10)', impact: 'high', icon: '🔥' },
        { factor: 'Attack Strength', advantage: awayTeam, value: '1.95 vs 1.75 xG/game', impact: 'medium', icon: '⚽' },
      ],
    },
  };
}
