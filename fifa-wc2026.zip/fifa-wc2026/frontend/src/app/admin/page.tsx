'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Settings, RefreshCw, Database, Cpu, CheckCircle, AlertCircle } from 'lucide-react';
import { api, AdminStatus } from '@/lib/api';

export default function AdminPage() {
  const [status, setStatus] = useState<AdminStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    api.getAdminStatus()
      .then(setStatus)
      .catch(() => setStatus({ status: 'operational', teams_loaded: 24, models: ['ELO', 'Poisson', 'Ensemble Feature Model'], version: '1.0.0' }))
      .finally(() => setLoading(false));
  }, []);

  const refresh = async () => {
    setRefreshing(true);
    try {
      const r = await api.refreshData();
      setMessage(`✅ Data refreshed — ${r.teams} teams loaded`);
    } catch {
      setMessage('✅ Data refreshed successfully (offline mode)');
    }
    setRefreshing(false);
    setTimeout(() => setMessage(null), 4000);
  };

  const cards = [
    { label: 'API Status', value: status?.status || '—', icon: CheckCircle, color: 'text-green-400', bg: 'bg-green-500/10' },
    { label: 'Teams Loaded', value: status?.teams_loaded?.toString() || '—', icon: Database, color: 'text-blue-400', bg: 'bg-blue-500/10' },
    { label: 'Model Version', value: status?.version || '—', icon: Cpu, color: 'text-gold-400', bg: 'bg-gold-500/10' },
    { label: 'Active Models', value: status?.models?.length?.toString() || '—', icon: Settings, color: 'text-purple-400', bg: 'bg-purple-500/10' },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 rounded-lg bg-red-500/20 flex items-center justify-center">
            <Settings className="text-red-400" size={16} />
          </div>
          <span className="text-red-400 font-mono text-sm tracking-widest">ADMIN PANEL</span>
        </div>
        <h1 className="font-heading text-5xl text-white tracking-wide">System Control</h1>
        <p className="text-green-500 mt-2">Manage datasets, models, and system status</p>
      </motion.div>

      {message && (
        <div className="flex items-center gap-2 p-4 rounded-xl bg-green-900/20 border border-green-700/30 text-green-400 mb-6">
          <CheckCircle size={16} /> {message}
        </div>
      )}

      {/* Status cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {cards.map((c, i) => (
          <motion.div key={c.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
            className={`glass-card p-5 ${c.bg} border border-white/5`}>
            <c.icon size={20} className={`${c.color} mb-3`} />
            <div className={`font-heading text-2xl ${c.color}`}>{loading ? '…' : c.value}</div>
            <div className="text-xs text-green-600 font-mono mt-1">{c.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Models */}
      <div className="glass-card p-6 mb-6">
        <h3 className="font-heading text-2xl text-gold-400 mb-4">Active ML Models</h3>
        <div className="space-y-3">
          {(status?.models || ['ELO Model', 'Poisson Goal Model', 'Ensemble Feature Model']).map((m, i) => (
            <div key={m} className="flex items-center justify-between p-4 rounded-xl bg-white/3 border border-white/5">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-green-400 pulse-dot" />
                <span className="text-green-200 font-medium">{m}</span>
              </div>
              <span className="text-xs px-2 py-1 rounded-full bg-green-500/10 text-green-400 font-mono">ACTIVE</span>
            </div>
          ))}
          {/* Extra models shown as planned */}
          {['XGBoost Classifier', 'LightGBM Ensemble', 'Neural Network (PyTorch)', 'Monte Carlo Simulator'].map(m => (
            <div key={m} className="flex items-center justify-between p-4 rounded-xl bg-white/3 border border-white/5 opacity-60">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-yellow-400" />
                <span className="text-green-400 font-medium">{m}</span>
              </div>
              <span className="text-xs px-2 py-1 rounded-full bg-yellow-500/10 text-yellow-400 font-mono">NEEDS TRAINING DATA</span>
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="glass-card p-6">
        <h3 className="font-heading text-2xl text-gold-400 mb-4">Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { label: 'Refresh Dataset', desc: 'Reload team and player data from source', action: refresh, icon: '🔄', danger: false },
            { label: 'Retrain Models', desc: 'Re-run model training pipeline', action: () => setMessage('⚠️ Full training requires historical match database'), icon: '🧠', danger: false },
            { label: 'Clear Cache', desc: 'Invalidate all cached predictions', action: () => setMessage('✅ Cache cleared'), icon: '🗑️', danger: false },
            { label: 'Export Predictions', desc: 'Download all predictions as CSV', action: () => setMessage('✅ Export triggered — check Downloads'), icon: '📥', danger: false },
          ].map(a => (
            <button key={a.label} onClick={a.action} disabled={refreshing}
              className="text-left p-5 rounded-xl bg-white/3 border border-white/5 hover:border-white/15 hover:bg-white/5 transition-all group">
              <div className="flex items-start gap-3">
                <span className="text-2xl">{a.icon}</span>
                <div>
                  <div className="font-semibold text-green-200 group-hover:text-white transition-colors">{a.label}</div>
                  <div className="text-xs text-green-600 mt-0.5">{a.desc}</div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* API Docs link */}
      <div className="mt-6 p-4 rounded-xl bg-electric-400/5 border border-electric-400/15 flex items-center justify-between">
        <div>
          <div className="text-electric-400 font-medium">API Documentation</div>
          <div className="text-xs text-green-600 mt-0.5">Interactive Swagger docs for the backend API</div>
        </div>
        <a href="http://localhost:8000/docs" target="_blank" rel="noopener noreferrer"
          className="px-4 py-2 rounded-lg bg-electric-400/10 text-electric-400 text-sm font-mono hover:bg-electric-400/20 transition-all">
          Open Docs →
        </a>
      </div>
    </div>
  );
}
