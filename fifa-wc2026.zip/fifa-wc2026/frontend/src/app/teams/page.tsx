'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Users, Search } from 'lucide-react';
import { getFlag, formatValue, CONFEDERATION_COLORS } from '@/lib/utils';

const TEAMS = [
  { name:'Argentina', code:'ARG', confederation:'CONMEBOL', fifa_ranking:1, elo_rating:2120, squad_value_m:900, wc_titles:3, form_points:24, xg_avg:2.1, best_result:'Champions' },
  { name:'France', code:'FRA', confederation:'UEFA', fifa_ranking:2, elo_rating:2085, squad_value_m:1150, wc_titles:2, form_points:21, xg_avg:1.95, best_result:'Champions' },
  { name:'Spain', code:'ESP', confederation:'UEFA', fifa_ranking:3, elo_rating:2060, squad_value_m:980, wc_titles:1, form_points:23, xg_avg:2.05, best_result:'Champions' },
  { name:'England', code:'ENG', confederation:'UEFA', fifa_ranking:4, elo_rating:2010, squad_value_m:1200, wc_titles:1, form_points:20, xg_avg:1.85, best_result:'Champions' },
  { name:'Brazil', code:'BRA', confederation:'CONMEBOL', fifa_ranking:5, elo_rating:2050, squad_value_m:1050, wc_titles:5, form_points:22, xg_avg:1.9, best_result:'Champions' },
  { name:'Portugal', code:'POR', confederation:'UEFA', fifa_ranking:6, elo_rating:2020, squad_value_m:920, wc_titles:0, form_points:21, xg_avg:1.9, best_result:'Third Place' },
  { name:'Netherlands', code:'NED', confederation:'UEFA', fifa_ranking:7, elo_rating:1995, squad_value_m:780, wc_titles:0, form_points:20, xg_avg:1.8, best_result:'Runners-up' },
  { name:'Germany', code:'GER', confederation:'UEFA', fifa_ranking:13, elo_rating:1985, squad_value_m:850, wc_titles:4, form_points:18, xg_avg:1.75, best_result:'Champions' },
  { name:'Colombia', code:'COL', confederation:'CONMEBOL', fifa_ranking:9, elo_rating:1940, squad_value_m:520, wc_titles:0, form_points:19, xg_avg:1.7, best_result:'Quarter-finals' },
  { name:'Morocco', code:'MAR', confederation:'CAF', fifa_ranking:14, elo_rating:1945, squad_value_m:420, wc_titles:0, form_points:18, xg_avg:1.5, best_result:'Semi-finals' },
  { name:'Italy', code:'ITA', confederation:'UEFA', fifa_ranking:9, elo_rating:1965, squad_value_m:680, wc_titles:4, form_points:18, xg_avg:1.65, best_result:'Champions' },
  { name:'Croatia', code:'CRO', confederation:'UEFA', fifa_ranking:10, elo_rating:1955, squad_value_m:390, wc_titles:0, form_points:19, xg_avg:1.6, best_result:'Runners-up' },
  { name:'Belgium', code:'BEL', confederation:'UEFA', fifa_ranking:3, elo_rating:1970, squad_value_m:720, wc_titles:0, form_points:17, xg_avg:1.7, best_result:'Third Place' },
  { name:'Uruguay', code:'URU', confederation:'CONMEBOL', fifa_ranking:14, elo_rating:1960, squad_value_m:450, wc_titles:2, form_points:16, xg_avg:1.55, best_result:'Champions' },
  { name:'USA', code:'USA', confederation:'CONCACAF', fifa_ranking:11, elo_rating:1910, squad_value_m:520, wc_titles:0, form_points:17, xg_avg:1.65, best_result:'Semi-finals' },
  { name:'Mexico', code:'MEX', confederation:'CONCACAF', fifa_ranking:15, elo_rating:1895, squad_value_m:380, wc_titles:0, form_points:15, xg_avg:1.6, best_result:'Quarter-finals' },
  { name:'Japan', code:'JPN', confederation:'AFC', fifa_ranking:18, elo_rating:1895, squad_value_m:340, wc_titles:0, form_points:17, xg_avg:1.55, best_result:'Quarter-finals' },
  { name:'South Korea', code:'KOR', confederation:'AFC', fifa_ranking:23, elo_rating:1870, squad_value_m:295, wc_titles:0, form_points:15, xg_avg:1.4, best_result:'Semi-finals' },
  { name:'Senegal', code:'SEN', confederation:'CAF', fifa_ranking:20, elo_rating:1900, squad_value_m:350, wc_titles:0, form_points:16, xg_avg:1.5, best_result:'Quarter-finals' },
  { name:'Australia', code:'AUS', confederation:'AFC', fifa_ranking:25, elo_rating:1855, squad_value_m:260, wc_titles:0, form_points:14, xg_avg:1.35, best_result:'Quarter-finals' },
  { name:'Canada', code:'CAN', confederation:'CONCACAF', fifa_ranking:48, elo_rating:1820, squad_value_m:310, wc_titles:0, form_points:13, xg_avg:1.45, best_result:'Group Stage' },
  { name:'Iran', code:'IRN', confederation:'AFC', fifa_ranking:22, elo_rating:1845, squad_value_m:180, wc_titles:0, form_points:15, xg_avg:1.3, best_result:'Group Stage' },
  { name:'Saudi Arabia', code:'KSA', confederation:'AFC', fifa_ranking:56, elo_rating:1790, squad_value_m:155, wc_titles:0, form_points:11, xg_avg:1.2, best_result:'Round of 16' },
  { name:'Ghana', code:'GHA', confederation:'CAF', fifa_ranking:60, elo_rating:1810, squad_value_m:190, wc_titles:0, form_points:12, xg_avg:1.25, best_result:'Quarter-finals' },
];

const CONFEDS = ['All', 'UEFA', 'CONMEBOL', 'CONCACAF', 'AFC', 'CAF'];
const SORTS = ['ELO Rating', 'FIFA Ranking', 'Squad Value', 'Form'];

export default function TeamsPage() {
  const [search, setSearch] = useState('');
  const [confed, setConfed] = useState('All');
  const [sort, setSort] = useState('ELO Rating');

  const filtered = TEAMS
    .filter(t => confed === 'All' || t.confederation === confed)
    .filter(t => t.name.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sort === 'ELO Rating') return b.elo_rating - a.elo_rating;
      if (sort === 'FIFA Ranking') return a.fifa_ranking - b.fifa_ranking;
      if (sort === 'Squad Value') return b.squad_value_m - a.squad_value_m;
      return b.form_points - a.form_points;
    });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
            <Users className="text-blue-400" size={16} />
          </div>
          <span className="text-blue-400 font-mono text-sm tracking-widest">TEAM DASHBOARD</span>
        </div>
        <h1 className="font-heading text-5xl md:text-6xl text-white tracking-wide">All 48 Teams</h1>
        <p className="text-green-500 mt-2">Browse all qualified nations with detailed statistics</p>
      </motion.div>

      {/* Filters */}
      <div className="glass-card p-4 mb-6 flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-48">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-green-600" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search team..."
            className="w-full pl-9 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg text-green-100 text-sm focus:outline-none focus:border-gold-500/40 placeholder-green-700" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {CONFEDS.map(c => (
            <button key={c} onClick={() => setConfed(c)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${confed === c ? 'bg-gold-500/20 text-gold-400 border border-gold-500/30' : 'bg-white/5 text-green-500 hover:bg-white/10'}`}>
              {c}
            </button>
          ))}
        </div>
        <select value={sort} onChange={e => setSort(e.target.value)}
          className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-green-300 text-sm focus:outline-none appearance-none cursor-pointer">
          {SORTS.map(s => <option key={s} value={s} className="bg-pitch-900">{s}</option>)}
        </select>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map((team, i) => (
          <motion.div key={team.name}
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.03 }}
            className="glass-card p-5 hover-lift group">
            <div className="flex items-start justify-between mb-3">
              <div className="text-4xl">{getFlag(team.name)}</div>
              <span className="text-xs px-2 py-1 rounded-full font-mono"
                style={{ background: `${CONFEDERATION_COLORS[team.confederation]}20`, color: CONFEDERATION_COLORS[team.confederation] }}>
                {team.confederation}
              </span>
            </div>
            <h3 className="font-heading text-xl text-white mb-0.5 group-hover:text-gold-300 transition-colors">{team.name}</h3>
            <p className="text-xs text-green-600 font-mono mb-4">FIFA #{team.fifa_ranking} · Best: {team.best_result}</p>
            <div className="grid grid-cols-2 gap-2 text-center mb-3">
              <div className="p-2 rounded-lg bg-white/3">
                <div className="text-xs text-green-600 font-mono">ELO</div>
                <div className="text-sm text-gold-400 font-bold">{team.elo_rating}</div>
              </div>
              <div className="p-2 rounded-lg bg-white/3">
                <div className="text-xs text-green-600 font-mono">VALUE</div>
                <div className="text-sm text-green-200 font-bold">{formatValue(team.squad_value_m)}</div>
              </div>
              <div className="p-2 rounded-lg bg-white/3">
                <div className="text-xs text-green-600 font-mono">xG/GAME</div>
                <div className="text-sm text-green-200 font-bold">{team.xg_avg}</div>
              </div>
              <div className="p-2 rounded-lg bg-white/3">
                <div className="text-xs text-green-600 font-mono">🏆 TITLES</div>
                <div className="text-sm text-green-200 font-bold">{team.wc_titles}</div>
              </div>
            </div>
            <Link href={`/teams/${encodeURIComponent(team.name)}`}
              className="block w-full text-center py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-green-400 hover:bg-gold-500/10 hover:border-gold-500/20 hover:text-gold-400 transition-all font-mono">
              VIEW FULL PROFILE →
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
