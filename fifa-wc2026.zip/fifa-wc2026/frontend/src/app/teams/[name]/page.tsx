'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { api, TeamData, PlayerData } from '@/lib/api';
import { getFlag, formatValue, POSITION_COLORS } from '@/lib/utils';
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, Tooltip } from 'recharts';

const TEAM_MAP: Record<string, any> = {
  'Argentina': { xg_avg:2.1, xga_avg:0.65, possession_avg:57.8, clean_sheets_pct:55, shots_on_target_avg:6.1, form_points:24, wc_appearances:18, manager_name:'Lionel Scaloni', manager_experience_years:6, avg_age:27.2 },
  'France': { xg_avg:1.95, xga_avg:0.80, possession_avg:56.5, clean_sheets_pct:48, shots_on_target_avg:5.5, form_points:21, wc_appearances:16, manager_name:'Didier Deschamps', manager_experience_years:12, avg_age:26.8 },
  'Spain': { xg_avg:2.05, xga_avg:0.70, possession_avg:62.5, clean_sheets_pct:50, shots_on_target_avg:5.9, form_points:23, wc_appearances:16, manager_name:'Luis de la Fuente', manager_experience_years:5, avg_age:25.5 },
  'England': { xg_avg:1.85, xga_avg:0.85, possession_avg:55.2, clean_sheets_pct:45, shots_on_target_avg:5.2, form_points:20, wc_appearances:16, manager_name:'Lee Carsley', manager_experience_years:4, avg_age:26.1 },
  'Brazil': { xg_avg:1.9, xga_avg:0.75, possession_avg:58.2, clean_sheets_pct:52, shots_on_target_avg:5.8, form_points:22, wc_appearances:22, manager_name:'Dorival Junior', manager_experience_years:15, avg_age:26.5 },
};

const PLAYERS_MAP: Record<string, PlayerData[]> = {
  'Argentina': [
    { name:'Lionel Messi', position:'FWD', age:38, club:'Inter Miami', market_value_m:20, caps:191, goals:109, assists:58, avg_rating:8.2, goals_per_90:0.72, assists_per_90:0.38, injured:false, fitness_pct:85, is_key_player:true },
    { name:'Emiliano Martinez', position:'GK', age:32, club:'Aston Villa', market_value_m:35, caps:42, goals:0, assists:0, avg_rating:7.8, goals_per_90:0, assists_per_90:0, injured:false, fitness_pct:100, is_key_player:true },
    { name:'Julian Alvarez', position:'FWD', age:25, club:'Atletico Madrid', market_value_m:90, caps:45, goals:22, assists:12, avg_rating:7.9, goals_per_90:0.60, assists_per_90:0.32, injured:false, fitness_pct:98, is_key_player:true },
    { name:'Rodrigo De Paul', position:'MID', age:31, club:'Atletico Madrid', market_value_m:45, caps:62, goals:9, assists:18, avg_rating:7.5, goals_per_90:0.18, assists_per_90:0.36, injured:false, fitness_pct:95, is_key_player:true },
    { name:'Cristian Romero', position:'DEF', age:27, club:'Tottenham', market_value_m:60, caps:38, goals:4, assists:2, avg_rating:7.6, goals_per_90:0.12, assists_per_90:0.06, injured:false, fitness_pct:100, is_key_player:true },
  ],
  'France': [
    { name:'Kylian Mbappe', position:'FWD', age:26, club:'Real Madrid', market_value_m:180, caps:92, goals:52, assists:32, avg_rating:8.5, goals_per_90:0.80, assists_per_90:0.48, injured:false, fitness_pct:96, is_key_player:true },
    { name:'Antoine Griezmann', position:'FWD', age:34, club:'Atletico Madrid', market_value_m:25, caps:138, goals:53, assists:40, avg_rating:7.8, goals_per_90:0.52, assists_per_90:0.39, injured:false, fitness_pct:92, is_key_player:true },
    { name:'Aurelien Tchouameni', position:'MID', age:25, club:'Real Madrid', market_value_m:100, caps:35, goals:3, assists:4, avg_rating:7.6, goals_per_90:0.12, assists_per_90:0.16, injured:false, fitness_pct:100, is_key_player:true },
    { name:'Mike Maignan', position:'GK', age:29, club:'AC Milan', market_value_m:50, caps:22, goals:0, assists:0, avg_rating:7.9, goals_per_90:0, assists_per_90:0, injured:false, fitness_pct:100, is_key_player:true },
  ],
  'Spain': [
    { name:'Lamine Yamal', position:'FWD', age:18, club:'Barcelona', market_value_m:200, caps:22, goals:8, assists:12, avg_rating:8.4, goals_per_90:0.48, assists_per_90:0.72, injured:false, fitness_pct:100, is_key_player:true },
    { name:'Pedri', position:'MID', age:23, club:'Barcelona', market_value_m:120, caps:35, goals:5, assists:12, avg_rating:8.2, goals_per_90:0.18, assists_per_90:0.43, injured:false, fitness_pct:95, is_key_player:true },
    { name:'Rodri', position:'MID', age:29, club:'Man City', market_value_m:120, caps:50, goals:5, assists:8, avg_rating:8.1, goals_per_90:0.12, assists_per_90:0.19, injured:false, fitness_pct:100, is_key_player:true },
  ],
};

function getDefault(name: string) {
  return TEAM_MAP[name] || { xg_avg:1.5, xga_avg:1.0, possession_avg:50, clean_sheets_pct:35, shots_on_target_avg:4.0, form_points:14, wc_appearances:5, manager_name:'Unknown', manager_experience_years:3, avg_age:26 };
}

export default function TeamDetailPage({ params }: { params: { name: string } }) {
  const teamName = decodeURIComponent(params.name);
  const stats = getDefault(teamName);
  const players = PLAYERS_MAP[teamName] || [];

  const radarData = [
    { subject: 'Attack', value: Math.round(stats.xg_avg * 40) },
    { subject: 'Defense', value: Math.round((3 - stats.xga_avg) * 35) },
    { subject: 'Possession', value: Math.round(stats.possession_avg) },
    { subject: 'Form', value: Math.round(stats.form_points * 3.5) },
    { subject: 'Experience', value: Math.round(Math.min(100, stats.wc_appearances * 4.5)) },
    { subject: 'Clean Sheets', value: Math.round(stats.clean_sheets_pct) },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link href="/teams" className="flex items-center gap-2 text-green-500 hover:text-green-300 mb-8 transition-colors">
        <ArrowLeft size={16} /> Back to Teams
      </Link>

      {/* Hero */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-8 mb-6">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
          <div className="text-8xl">{getFlag(teamName)}</div>
          <div className="flex-1 text-center md:text-left">
            <h1 className="font-heading text-6xl text-white tracking-wide">{teamName}</h1>
            <div className="flex flex-wrap gap-3 mt-3 justify-center md:justify-start">
              <span className="px-3 py-1 rounded-full bg-gold-500/15 border border-gold-500/20 text-gold-400 text-sm font-mono">
                👨‍💼 {stats.manager_name}
              </span>
              <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-green-400 text-sm font-mono">
                ⏱ {stats.manager_experience_years}y experience
              </span>
              <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-green-400 text-sm font-mono">
                📅 Avg age: {stats.avg_age}
              </span>
            </div>
          </div>
          <Link href={`/match-predictor?home=${encodeURIComponent(teamName)}`}
            className="px-6 py-3 rounded-xl bg-gold-gradient text-pitch-950 font-bold text-sm hover:shadow-gold transition-all">
            ⚽ Predict Match
          </Link>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Stats */}
        <div className="glass-card p-6">
          <h3 className="font-heading text-2xl text-gold-400 mb-4">Team Statistics</h3>
          <div className="space-y-4">
            {[
              { label: 'xG per Game', value: stats.xg_avg.toFixed(2), max: 3, color: '#22C55E' },
              { label: 'xGA per Game', value: stats.xga_avg.toFixed(2), max: 3, color: '#EF4444', invert: true },
              { label: 'Possession %', value: stats.possession_avg.toFixed(1) + '%', max: 100, color: '#3B82F6', raw: stats.possession_avg },
              { label: 'Clean Sheets %', value: stats.clean_sheets_pct.toFixed(0) + '%', max: 100, color: '#8B5CF6', raw: stats.clean_sheets_pct },
              { label: 'Shots on Target', value: stats.shots_on_target_avg.toFixed(1), max: 10, color: '#F59E0B' },
            ].map(s => {
              const rawVal = s.raw ?? parseFloat(s.value);
              const pct = s.invert ? (1 - rawVal / s.max) * 100 : (rawVal / s.max) * 100;
              return (
                <div key={s.label}>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-green-300">{s.label}</span>
                    <span className="font-mono font-bold" style={{ color: s.color }}>{s.value}</span>
                  </div>
                  <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                    <motion.div className="h-full rounded-full" style={{ background: s.color }}
                      initial={{ width: 0 }} animate={{ width: `${Math.min(100, pct)}%` }}
                      transition={{ duration: 1 }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Radar */}
        <div className="glass-card p-6">
          <h3 className="font-heading text-2xl text-gold-400 mb-4">Performance Radar</h3>
          <ResponsiveContainer width="100%" height={260}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="rgba(255,255,255,0.1)" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#4ADE80', fontSize: 12 }} />
              <Radar dataKey="value" stroke="#FFC107" fill="#FFC107" fillOpacity={0.15} strokeWidth={2} />
              <Tooltip contentStyle={{ background: '#041409', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8 }} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Players */}
      {players.length > 0 && (
        <div className="glass-card p-6">
          <h3 className="font-heading text-2xl text-gold-400 mb-4">Key Players</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {players.map((p, i) => (
              <motion.div key={p.name} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                className="flex items-center gap-4 p-4 rounded-xl bg-white/3 border border-white/5 hover:border-white/10 transition-all">
                <div className="w-12 h-12 rounded-full flex items-center justify-center font-heading text-lg"
                  style={{ background: `${POSITION_COLORS[p.position]}20`, color: POSITION_COLORS[p.position] }}>
                  {p.position}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-green-100 truncate">{p.name}</span>
                    {p.is_key_player && <span className="text-gold-400 text-xs">⭐</span>}
                    {p.injured && <span className="text-red-400 text-xs px-1.5 py-0.5 bg-red-400/10 rounded">INJURED</span>}
                  </div>
                  <div className="text-xs text-green-600">{p.club} · {p.caps} caps</div>
                  <div className="flex gap-3 mt-1 text-xs font-mono">
                    <span className="text-green-400">⚽ {p.goals}G</span>
                    <span className="text-blue-400">🅰️ {p.assists}A</span>
                    <span className="text-gold-400">★ {p.avg_rating}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-green-200">{formatValue(p.market_value_m)}</div>
                  <div className="text-xs text-green-600 font-mono mt-1">
                    <span className={`px-1.5 py-0.5 rounded ${p.fitness_pct >= 90 ? 'bg-green-500/20 text-green-400' : p.fitness_pct >= 70 ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'}`}>
                      {p.fitness_pct}% fit
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
