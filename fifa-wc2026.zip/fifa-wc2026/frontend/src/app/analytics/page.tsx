'use client';

import { motion } from 'framer-motion';
import { BarChart2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, ScatterChart, Scatter, LineChart, Line, CartesianGrid, Legend } from 'recharts';
import { getFlag, CONFEDERATION_COLORS } from '@/lib/utils';

const ELO_DATA = [
  { team: 'Argentina', elo: 2120, flag: '🇦🇷' }, { team: 'France', elo: 2085, flag: '🇫🇷' },
  { team: 'Spain', elo: 2060, flag: '🇪🇸' }, { team: 'Brazil', elo: 2050, flag: '🇧🇷' },
  { team: 'England', elo: 2010, flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' }, { team: 'Portugal', elo: 2020, flag: '🇵🇹' },
  { team: 'Netherlands', elo: 1995, flag: '🇳🇱' }, { team: 'Germany', elo: 1985, flag: '🇩🇪' },
  { team: 'Italy', elo: 1965, flag: '🇮🇹' }, { team: 'Croatia', elo: 1955, flag: '🇭🇷' },
];

const XG_DATA = [
  { team: 'Argentina', xg: 2.1, xga: 0.65 }, { team: 'Spain', xg: 2.05, xga: 0.70 },
  { team: 'France', xg: 1.95, xga: 0.80 }, { team: 'Brazil', xg: 1.90, xga: 0.75 },
  { team: 'England', xg: 1.85, xga: 0.85 }, { team: 'Portugal', xg: 1.90, xga: 0.82 },
  { team: 'Netherlands', xg: 1.80, xga: 0.88 }, { team: 'Germany', xg: 1.75, xga: 0.95 },
  { team: 'Colombia', xg: 1.70, xga: 0.92 }, { team: 'Italy', xg: 1.65, xga: 0.88 },
];

const VALUE_DATA = [
  { team: 'England', value: 1200, confed: 'UEFA' }, { team: 'France', value: 1150, confed: 'UEFA' },
  { team: 'Brazil', value: 1050, confed: 'CONMEBOL' }, { team: 'Spain', value: 980, confed: 'UEFA' },
  { team: 'Argentina', value: 900, confed: 'CONMEBOL' }, { team: 'Portugal', value: 920, confed: 'UEFA' },
  { team: 'Germany', value: 850, confed: 'UEFA' }, { team: 'Netherlands', value: 780, confed: 'UEFA' },
  { team: 'Belgium', value: 720, confed: 'UEFA' }, { team: 'Italy', value: 680, confed: 'UEFA' },
];

const TITLE_DATA = [
  { team: 'Brazil', titles: 5, appearances: 22 },
  { team: 'Germany', titles: 4, appearances: 20 },
  { team: 'Italy', titles: 4, appearances: 18 },
  { team: 'Argentina', titles: 3, appearances: 18 },
  { team: 'France', titles: 2, appearances: 16 },
  { team: 'Uruguay', titles: 2, appearances: 14 },
  { team: 'England', titles: 1, appearances: 16 },
  { team: 'Spain', titles: 1, appearances: 16 },
];

const COLORS = ['#FFC107','#FFD54F','#4CAF50','#00BCD4','#8BC34A','#FF9800','#9C27B0','#F44336','#2196F3','#E91E63'];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload?.length) {
    return (
      <div className="bg-pitch-900 border border-white/10 rounded-xl p-3 text-xs">
        <p className="text-gold-400 font-mono mb-1">{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} style={{ color: p.color }}>{p.name}: {p.value}</p>
        ))}
      </div>
    );
  }
  return null;
};

export default function AnalyticsPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 rounded-lg bg-pink-500/20 flex items-center justify-center">
            <BarChart2 className="text-pink-400" size={16} />
          </div>
          <span className="text-pink-400 font-mono text-sm tracking-widest">ANALYTICS DASHBOARD</span>
        </div>
        <h1 className="font-heading text-5xl md:text-6xl text-white tracking-wide">Data & Analytics</h1>
        <p className="text-green-500 mt-2">Interactive charts and statistical breakdowns for all 48 teams</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ELO Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="glass-card p-6">
          <h3 className="font-heading text-xl text-gold-400 mb-4">Top 10 ELO Ratings</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={ELO_DATA} layout="vertical" margin={{ left: 60 }}>
              <XAxis type="number" domain={[1900, 2150]} tick={{ fill: '#4ADE80', fontSize: 11 }} />
              <YAxis type="category" dataKey="team" tick={{ fill: '#4ADE80', fontSize: 11 }} width={80} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="elo" radius={[0, 4, 4, 0]}>
                {ELO_DATA.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* xG vs xGA */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          className="glass-card p-6">
          <h3 className="font-heading text-xl text-gold-400 mb-1">Attack vs Defense (xG / xGA)</h3>
          <p className="text-green-600 text-xs mb-4 font-mono">Top-left = best defensive teams · Bottom-right = best attacking</p>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={XG_DATA}>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="team" tick={{ fill: '#4ADE80', fontSize: 10 }} angle={-30} textAnchor="end" height={50} />
              <YAxis tick={{ fill: '#4ADE80', fontSize: 11 }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ color: '#4ADE80', fontSize: 12 }} />
              <Line type="monotone" dataKey="xg" stroke="#FFC107" strokeWidth={2} dot={{ fill: '#FFC107' }} name="xG (Attack)" />
              <Line type="monotone" dataKey="xga" stroke="#EF4444" strokeWidth={2} dot={{ fill: '#EF4444' }} name="xGA (Conceded)" />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Squad Values */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="glass-card p-6">
          <h3 className="font-heading text-xl text-gold-400 mb-4">Squad Market Values (€M)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={VALUE_DATA} margin={{ bottom: 40 }}>
              <XAxis dataKey="team" tick={{ fill: '#4ADE80', fontSize: 10 }} angle={-40} textAnchor="end" />
              <YAxis tick={{ fill: '#4ADE80', fontSize: 11 }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" name="Value (€M)" radius={[4, 4, 0, 0]}>
                {VALUE_DATA.map((d, i) => (
                  <Cell key={i} fill={CONFEDERATION_COLORS[d.confed] || '#FFC107'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* WC History */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
          className="glass-card p-6">
          <h3 className="font-heading text-xl text-gold-400 mb-4">World Cup Titles & Appearances</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={TITLE_DATA} margin={{ bottom: 10 }}>
              <CartesianGrid stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="team" tick={{ fill: '#4ADE80', fontSize: 11 }} />
              <YAxis tick={{ fill: '#4ADE80', fontSize: 11 }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ color: '#4ADE80', fontSize: 12 }} />
              <Bar dataKey="titles" fill="#FFC107" name="🏆 Titles" radius={[4, 4, 0, 0]} />
              <Bar dataKey="appearances" fill="#00BCD4" name="Appearances" radius={[4, 4, 0, 0]} opacity={0.6} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Confederation breakdown */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
        className="glass-card p-6 mt-6">
        <h3 className="font-heading text-2xl text-gold-400 mb-6">Teams by Confederation</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {Object.entries({ UEFA: 16, CONMEBOL: 6, CONCACAF: 6, AFC: 8, CAF: 9, OFC: 1 }).map(([conf, count]) => (
            <div key={conf} className="text-center p-4 rounded-xl border"
              style={{ borderColor: `${CONFEDERATION_COLORS[conf]}30`, background: `${CONFEDERATION_COLORS[conf]}10` }}>
              <div className="font-heading text-3xl mb-1" style={{ color: CONFEDERATION_COLORS[conf] }}>{count}</div>
              <div className="text-xs font-mono" style={{ color: CONFEDERATION_COLORS[conf] }}>{conf}</div>
              <div className="text-xs text-green-700 mt-1">Teams</div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
