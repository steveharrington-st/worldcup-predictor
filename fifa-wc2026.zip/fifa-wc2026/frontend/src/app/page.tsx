'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Trophy, TrendingUp, Star, Zap } from 'lucide-react';
import { api, TeamPrediction } from '@/lib/api';
import { getFlag, formatValue, getProbabilityColor } from '@/lib/utils';
import HeroSection from '@/components/dashboard/HeroSection';
import PredictionCard from '@/components/prediction/PredictionCard';
import StatsBar from '@/components/dashboard/StatsBar';

export default function HomePage() {
  const [predictions, setPredictions] = useState<TeamPrediction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.getTournamentPredictions()
      .then(data => {
        setPredictions(data.predictions);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        // Use fallback data when API unavailable
        setPredictions(FALLBACK_PREDICTIONS);
        setLoading(false);
      });
  }, []);

  return (
    <div className="relative">
      <HeroSection />
      <StatsBar />

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-10"
        >
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-lg bg-gold-500/20 flex items-center justify-center">
                <Trophy className="text-gold-400" size={16} />
              </div>
              <span className="text-gold-400 font-mono text-sm tracking-widest uppercase">
                AI Tournament Predictions
              </span>
            </div>
            <h2 className="font-heading text-4xl md:text-5xl text-white tracking-wide">
              World Cup 2026 Winner Odds
            </h2>
            <p className="text-green-500 mt-2 text-sm">
              Ensemble ML model · Updated with latest form & rankings
            </p>
          </div>
          <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-xl bg-green-900/20 border border-green-700/20">
            <Zap size={14} className="text-gold-400" />
            <span className="text-xs text-green-400 font-mono">{predictions.length} TEAMS</span>
          </div>
        </motion.div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(12)].map((_, i) => (
              <div key={i} className="glass-card p-6 animate-pulse">
                <div className="h-5 bg-white/5 rounded mb-3 w-3/4" />
                <div className="h-3 bg-white/5 rounded mb-2 w-1/2" />
                <div className="h-2 bg-white/5 rounded w-full" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {predictions.slice(0, 18).map((team, index) => (
              <PredictionCard key={team.team} team={team} rank={index + 1} />
            ))}
          </div>
        )}

        {/* Bottom predictions - compact list */}
        {!loading && predictions.length > 18 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-8 glass-card p-6"
          >
            <h3 className="font-heading text-2xl text-green-400 mb-4">Remaining Teams</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {predictions.slice(18).map((team, i) => (
                <div key={team.team} className="flex items-center justify-between p-3 rounded-lg bg-white/3 border border-white/5 hover:border-white/10 transition-all">
                  <div className="flex items-center gap-2">
                    <span className="text-green-700 text-xs font-mono w-5">#{18 + i + 1}</span>
                    <span className="text-lg">{getFlag(team.team)}</span>
                    <span className="text-sm text-green-200">{team.team}</span>
                  </div>
                  <span className="text-xs font-mono" style={{ color: getProbabilityColor(team.win_probability / 100) }}>
                    {team.win_probability.toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </section>
    </div>
  );
}

const FALLBACK_PREDICTIONS: TeamPrediction[] = [
  { rank: 1, team: 'Argentina', win_probability: 18.5, elo_rating: 2120, fifa_ranking: 1, squad_value_m: 900, form_points: 24, wc_titles: 3 },
  { rank: 2, team: 'France', win_probability: 16.2, elo_rating: 2085, fifa_ranking: 2, squad_value_m: 1150, form_points: 21, wc_titles: 2 },
  { rank: 3, team: 'Spain', win_probability: 13.8, elo_rating: 2060, fifa_ranking: 3, squad_value_m: 980, form_points: 23, wc_titles: 1 },
  { rank: 4, team: 'England', win_probability: 12.1, elo_rating: 2010, fifa_ranking: 4, squad_value_m: 1200, form_points: 20, wc_titles: 1 },
  { rank: 5, team: 'Brazil', win_probability: 11.9, elo_rating: 2050, fifa_ranking: 5, squad_value_m: 1050, form_points: 22, wc_titles: 5 },
  { rank: 6, team: 'Portugal', win_probability: 8.4, elo_rating: 2020, fifa_ranking: 6, squad_value_m: 920, form_points: 21, wc_titles: 0 },
  { rank: 7, team: 'Netherlands', win_probability: 6.2, elo_rating: 1995, fifa_ranking: 7, squad_value_m: 780, form_points: 20, wc_titles: 0 },
  { rank: 8, team: 'Germany', win_probability: 5.8, elo_rating: 1985, fifa_ranking: 13, squad_value_m: 850, form_points: 18, wc_titles: 4 },
  { rank: 9, team: 'Colombia', win_probability: 3.2, elo_rating: 1940, fifa_ranking: 9, squad_value_m: 520, form_points: 19, wc_titles: 0 },
  { rank: 10, team: 'Morocco', win_probability: 2.8, elo_rating: 1945, fifa_ranking: 14, squad_value_m: 420, form_points: 18, wc_titles: 0 },
  { rank: 11, team: 'Italy', win_probability: 2.5, elo_rating: 1965, fifa_ranking: 9, squad_value_m: 680, form_points: 18, wc_titles: 4 },
  { rank: 12, team: 'Croatia', win_probability: 2.1, elo_rating: 1955, fifa_ranking: 10, squad_value_m: 390, form_points: 19, wc_titles: 0 },
  { rank: 13, team: 'Uruguay', win_probability: 1.8, elo_rating: 1960, fifa_ranking: 14, squad_value_m: 450, form_points: 16, wc_titles: 2 },
  { rank: 14, team: 'Belgium', win_probability: 1.5, elo_rating: 1970, fifa_ranking: 3, squad_value_m: 720, form_points: 17, wc_titles: 0 },
  { rank: 15, team: 'USA', win_probability: 1.2, elo_rating: 1910, fifa_ranking: 11, squad_value_m: 520, form_points: 17, wc_titles: 0 },
  { rank: 16, team: 'Japan', win_probability: 1.0, elo_rating: 1895, fifa_ranking: 18, squad_value_m: 340, form_points: 17, wc_titles: 0 },
  { rank: 17, team: 'Senegal', win_probability: 0.8, elo_rating: 1900, fifa_ranking: 20, squad_value_m: 350, form_points: 16, wc_titles: 0 },
  { rank: 18, team: 'Mexico', win_probability: 0.7, elo_rating: 1895, fifa_ranking: 15, squad_value_m: 380, form_points: 15, wc_titles: 0 },
  { rank: 19, team: 'South Korea', win_probability: 0.5, elo_rating: 1870, fifa_ranking: 23, squad_value_m: 295, form_points: 15, wc_titles: 0 },
  { rank: 20, team: 'Australia', win_probability: 0.4, elo_rating: 1855, fifa_ranking: 25, squad_value_m: 260, form_points: 14, wc_titles: 0 },
  { rank: 21, team: 'Canada', win_probability: 0.3, elo_rating: 1820, fifa_ranking: 48, squad_value_m: 310, form_points: 13, wc_titles: 0 },
  { rank: 22, team: 'Iran', win_probability: 0.2, elo_rating: 1845, fifa_ranking: 22, squad_value_m: 180, form_points: 15, wc_titles: 0 },
  { rank: 23, team: 'Saudi Arabia', win_probability: 0.15, elo_rating: 1790, fifa_ranking: 56, squad_value_m: 155, form_points: 11, wc_titles: 0 },
  { rank: 24, team: 'Ghana', win_probability: 0.1, elo_rating: 1810, fifa_ranking: 60, squad_value_m: 190, form_points: 12, wc_titles: 0 },
];
