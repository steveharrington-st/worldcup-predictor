from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, JSON, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.core.config import settings

engine = create_async_engine(settings.DATABASE_URL, echo=False, pool_size=20, max_overflow=40)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


class Base(DeclarativeBase):
    pass


class Team(Base):
    __tablename__ = "teams"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True, nullable=False)
    code = Column(String(3), unique=True)
    confederation = Column(String(10))
    fifa_ranking = Column(Integer)
    elo_rating = Column(Float)
    squad_value_m = Column(Float)  # in millions EUR
    avg_age = Column(Float)
    qualified = Column(Boolean, default=False)
    group_code = Column(String(1))
    logo_url = Column(String(500))
    # Advanced stats
    goals_scored_avg = Column(Float)
    goals_conceded_avg = Column(Float)
    xg_avg = Column(Float)
    xga_avg = Column(Float)
    possession_avg = Column(Float)
    pass_accuracy_avg = Column(Float)
    shots_on_target_avg = Column(Float)
    clean_sheets_pct = Column(Float)
    form_points = Column(Float)  # last 10 matches
    wc_titles = Column(Integer, default=0)
    wc_appearances = Column(Integer, default=0)
    best_result = Column(String(50))
    manager_name = Column(String(100))
    manager_experience_years = Column(Integer)
    home_advantage = Column(Float, default=0.0)
    extra_data = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    players = relationship("Player", back_populates="team")
    rankings = relationship("FIFARanking", back_populates="team")


class Player(Base):
    __tablename__ = "players"
    id = Column(Integer, primary_key=True, index=True)
    team_id = Column(Integer, ForeignKey("teams.id"))
    name = Column(String(100), nullable=False)
    position = Column(String(5))  # GK, DEF, MID, FWD
    age = Column(Integer)
    club = Column(String(100))
    market_value_m = Column(Float)
    caps = Column(Integer, default=0)
    goals = Column(Integer, default=0)
    assists = Column(Integer, default=0)
    minutes_played = Column(Integer, default=0)
    avg_rating = Column(Float)
    goals_per_90 = Column(Float)
    assists_per_90 = Column(Float)
    injured = Column(Boolean, default=False)
    injury_details = Column(String(200))
    suspended = Column(Boolean, default=False)
    fitness_pct = Column(Float, default=100.0)
    is_key_player = Column(Boolean, default=False)
    extra_data = Column(JSON)
    team = relationship("Team", back_populates="players")


class Match(Base):
    __tablename__ = "matches"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime)
    tournament = Column(String(100))
    home_team = Column(String(100))
    away_team = Column(String(100))
    home_score = Column(Integer)
    away_score = Column(Integer)
    home_xg = Column(Float)
    away_xg = Column(Float)
    neutral = Column(Boolean, default=False)
    stage = Column(String(50))
    city = Column(String(100))
    country = Column(String(100))
    extra_data = Column(JSON)


class FIFARanking(Base):
    __tablename__ = "fifa_rankings"
    id = Column(Integer, primary_key=True, index=True)
    team_id = Column(Integer, ForeignKey("teams.id"))
    date = Column(DateTime)
    ranking = Column(Integer)
    points = Column(Float)
    team = relationship("Team", back_populates="rankings")


class Prediction(Base):
    __tablename__ = "predictions"
    id = Column(Integer, primary_key=True, index=True)
    home_team = Column(String(100))
    away_team = Column(String(100))
    home_win_prob = Column(Float)
    draw_prob = Column(Float)
    away_win_prob = Column(Float)
    home_goals_pred = Column(Float)
    away_goals_pred = Column(Float)
    home_xg = Column(Float)
    away_xg = Column(Float)
    confidence = Column(Float)
    model_version = Column(String(20))
    extra_data = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)


class SimulationResult(Base):
    __tablename__ = "simulation_results"
    id = Column(Integer, primary_key=True, index=True)
    n_simulations = Column(Integer)
    results = Column(JSON)  # team -> {winner_prob, final_prob, semi_prob, qf_prob, group_prob}
    model_version = Column(String(20))
    created_at = Column(DateTime, default=datetime.utcnow)


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()
