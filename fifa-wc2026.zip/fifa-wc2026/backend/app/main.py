from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from contextlib import asynccontextmanager
import logging

from app.core.config import settings
from app.api.routes import predictions, teams, players, tournament, analytics, admin
from app.db.database import init_db
from app.ml.pipeline.model_manager import ModelManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting FIFA WC 2026 Prediction API...")
    await init_db()
    app.state.model_manager = ModelManager()
    await app.state.model_manager.load_models()
    logger.info("Models loaded successfully")
    yield
    logger.info("Shutting down...")


app = FastAPI(
    title="FIFA World Cup 2026 Prediction API",
    description="AI-powered football analytics and prediction platform",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(predictions.router, prefix="/api/v1/predictions", tags=["Predictions"])
app.include_router(teams.router, prefix="/api/v1/teams", tags=["Teams"])
app.include_router(players.router, prefix="/api/v1/players", tags=["Players"])
app.include_router(tournament.router, prefix="/api/v1/tournament", tags=["Tournament"])
app.include_router(analytics.router, prefix="/api/v1/analytics", tags=["Analytics"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["Admin"])


@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": "1.0.0"}


@app.get("/")
async def root():
    return {
        "message": "FIFA World Cup 2026 Prediction API",
        "docs": "/docs",
        "version": "1.0.0"
    }
