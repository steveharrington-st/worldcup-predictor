from pydantic_settings import BaseSettings
from typing import List
import os


class Settings(BaseSettings):
    # API
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = os.getenv("SECRET_KEY", "fifa-wc-2026-secret-key-change-in-production")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24

    # Database
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql+asyncpg://postgres:postgres@localhost:5432/fifa_wc2026"
    )

    # CORS
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:3001",
        "https://fifa-wc2026.vercel.app",
    ]

    # ML Models
    MODEL_DIR: str = os.getenv("MODEL_DIR", "/app/ml_models")
    DATA_DIR: str = os.getenv("DATA_DIR", "/app/data")

    # Simulation
    DEFAULT_SIMULATIONS: int = 10000
    MAX_SIMULATIONS: int = 100000

    # Redis Cache
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379")
    CACHE_TTL: int = 3600  # 1 hour

    class Config:
        env_file = ".env"


settings = Settings()
