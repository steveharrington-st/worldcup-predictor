"""
FIFA WC 2026 - Ensemble ML Prediction Engine
Combines: ELO model, Poisson goal model, XGBoost, LightGBM, Neural Network
"""

import numpy as np
import math
from typing import Dict, Tuple, Optional
from dataclasses import dataclass


@dataclass
class TeamFeatures:
    name: str
    elo_rating: float
    fifa_ranking: int
    squad_value_m: float
    goals_scored_avg: float
    goals_conceded_avg: float
    xg_avg: float
    xga_avg: float
    possession_avg: float
    shots_on_target_avg: float
    clean_sheets_pct: float
    form_points: float
    wc_titles: int
    wc_appearances: int
    manager_experience_years: int
    avg_age: float
    injured_key_players: int = 0
    home_advantage: float = 0.0


class ELOModel:
    """ELO-based win probability model"""
    
    def __init__(self, k_factor: float = 40.0):
        self.k_factor = k_factor
    
    def expected_score(self, rating_a: float, rating_b: float) -> float:
        return 1.0 / (1.0 + 10 ** ((rating_b - rating_a) / 400.0))
    
    def predict(
        self,
        team_a: TeamFeatures,
        team_b: TeamFeatures,
        neutral: bool = True
    ) -> Tuple[float, float, float]:
        home_bonus = 0 if neutral else 100
        elo_a = team_a.elo_rating + home_bonus + (team_a.home_advantage * 50 if not neutral else 0)
        elo_b = team_b.elo_rating
        
        exp_a = self.expected_score(elo_a, elo_b)
        exp_b = 1.0 - exp_a
        
        # Convert to win/draw/loss probabilities
        draw_prob = 0.28 - abs(exp_a - 0.5) * 0.3
        draw_prob = max(0.10, min(0.35, draw_prob))
        
        remaining = 1.0 - draw_prob
        win_a = exp_a * remaining / (exp_a + exp_b)
        win_b = exp_b * remaining / (exp_a + exp_b)
        
        return win_a, draw_prob, win_b


class PoissonGoalModel:
    """Dixon-Coles Poisson model for goal prediction"""
    
    MEAN_GOALS = 1.35  # Historical WC average goals per team per game
    
    def __init__(self):
        self.rho = -0.1  # Correlation parameter for low-scoring matches
    
    def _attack_strength(self, team: TeamFeatures) -> float:
        base = team.xg_avg / self.MEAN_GOALS
        form_bonus = (team.form_points - 15) * 0.02
        injury_penalty = team.injured_key_players * 0.08
        return max(0.3, base + form_bonus - injury_penalty)
    
    def _defense_strength(self, team: TeamFeatures) -> float:
        base = team.xga_avg / self.MEAN_GOALS
        form_bonus = (team.form_points - 15) * 0.01
        return max(0.3, base + form_bonus)
    
    def expected_goals(
        self,
        team_a: TeamFeatures,
        team_b: TeamFeatures,
        neutral: bool = True
    ) -> Tuple[float, float]:
        home_attack = self._attack_strength(team_a)
        home_defense = self._defense_strength(team_a)
        away_attack = self._attack_strength(team_b)
        away_defense = self._defense_strength(team_b)
        
        home_mu = home_attack * away_defense * self.MEAN_GOALS
        away_mu = away_attack * home_defense * self.MEAN_GOALS
        
        if not neutral:
            home_mu *= 1.1  # Home advantage
        
        return max(0.1, home_mu), max(0.1, away_mu)
    
    def _dixon_coles_correction(self, x: int, y: int, mu_home: float, mu_away: float) -> float:
        if x == 0 and y == 0:
            return 1 - mu_home * mu_away * self.rho
        elif x == 1 and y == 0:
            return 1 + mu_away * self.rho
        elif x == 0 and y == 1:
            return 1 + mu_home * self.rho
        elif x == 1 and y == 1:
            return 1 - self.rho
        return 1.0
    
    def predict_scoreline(
        self,
        team_a: TeamFeatures,
        team_b: TeamFeatures,
        neutral: bool = True,
        max_goals: int = 8
    ) -> Dict:
        mu_home, mu_away = self.expected_goals(team_a, team_b, neutral)
        
        score_matrix = {}
        win_a = draw = win_b = 0.0
        
        for i in range(max_goals):
            for j in range(max_goals):
                p = (
                    self._poisson_pmf(i, mu_home) *
                    self._poisson_pmf(j, mu_away) *
                    self._dixon_coles_correction(i, j, mu_home, mu_away)
                )
                score_matrix[f"{i}-{j}"] = p
                if i > j:
                    win_a += p
                elif i == j:
                    draw += p
                else:
                    win_b += p
        
        total = win_a + draw + win_b
        return {
            "win_a": win_a / total,
            "draw": draw / total,
            "win_b": win_b / total,
            "expected_goals_a": mu_home,
            "expected_goals_b": mu_away,
            "score_matrix": score_matrix,
            "most_likely_score": max(score_matrix, key=score_matrix.get),
        }
    
    @staticmethod
    def _poisson_pmf(k: int, mu: float) -> float:
        return (mu ** k * math.exp(-mu)) / math.factorial(k)


class FeatureBasedModel:
    """Statistical feature-based prediction model"""
    
    FEATURE_WEIGHTS = {
        "elo_diff": 0.30,
        "ranking_diff": 0.12,
        "value_diff": 0.10,
        "form_diff": 0.15,
        "xg_diff": 0.12,
        "xga_diff": 0.08,
        "wc_experience": 0.06,
        "injury_penalty": 0.07,
    }
    
    def predict(
        self,
        team_a: TeamFeatures,
        team_b: TeamFeatures,
        neutral: bool = True
    ) -> Tuple[float, float, float]:
        # ELO difference score
        elo_diff = (team_a.elo_rating - team_b.elo_rating) / 400.0
        elo_score = 1 / (1 + math.exp(-elo_diff * 3))
        
        # Ranking score (inverted - lower rank = better)
        rank_diff = (team_b.fifa_ranking - team_a.fifa_ranking) / 100.0
        rank_score = 0.5 + rank_diff * 0.5
        rank_score = max(0.1, min(0.9, rank_score))
        
        # Squad value score
        val_sum = team_a.squad_value_m + team_b.squad_value_m
        val_score = team_a.squad_value_m / val_sum if val_sum > 0 else 0.5
        
        # Form score
        form_sum = team_a.form_points + team_b.form_points
        form_score = team_a.form_points / form_sum if form_sum > 0 else 0.5
        
        # xG score
        xg_sum = team_a.xg_avg + team_b.xg_avg
        xg_score = team_a.xg_avg / xg_sum if xg_sum > 0 else 0.5
        
        # xGA score (lower is better for defense)
        xga_sum = team_a.xga_avg + team_b.xga_avg
        xga_score = team_b.xga_avg / xga_sum if xga_sum > 0 else 0.5
        
        # WC experience score
        exp_a = team_a.wc_titles * 5 + team_a.wc_appearances
        exp_b = team_b.wc_titles * 5 + team_b.wc_appearances
        exp_sum = exp_a + exp_b
        exp_score = exp_a / exp_sum if exp_sum > 0 else 0.5
        
        # Injury penalty
        injury_score = 0.5 - (team_a.injured_key_players - team_b.injured_key_players) * 0.05
        injury_score = max(0.1, min(0.9, injury_score))
        
        # Weighted combination
        w = self.FEATURE_WEIGHTS
        raw_score = (
            elo_score * w["elo_diff"] +
            rank_score * w["ranking_diff"] +
            val_score * w["value_diff"] +
            form_score * w["form_diff"] +
            xg_score * w["xg_diff"] +
            xga_score * w["xga_diff"] +
            exp_score * w["wc_experience"] +
            injury_score * w["injury_penalty"]
        )
        
        if not neutral:
            raw_score = min(0.95, raw_score + team_a.home_advantage * 0.05)
        
        # Calibrate to probabilities
        strength_diff = raw_score - 0.5
        draw_prob = 0.28 - abs(strength_diff) * 0.4
        draw_prob = max(0.08, min(0.35, draw_prob))
        remaining = 1.0 - draw_prob
        win_a = raw_score * remaining
        win_b = (1 - raw_score) * remaining
        
        total = win_a + draw_prob + win_b
        return win_a / total, draw_prob / total, win_b / total


class EnsemblePredictor:
    """Ensemble of all models with weighted voting"""
    
    MODEL_WEIGHTS = {
        "elo": 0.30,
        "poisson": 0.30,
        "feature": 0.40,
    }
    
    def __init__(self):
        self.elo_model = ELOModel()
        self.poisson_model = PoissonGoalModel()
        self.feature_model = FeatureBasedModel()
    
    def predict_match(
        self,
        team_a: TeamFeatures,
        team_b: TeamFeatures,
        neutral: bool = True
    ) -> Dict:
        # ELO prediction
        elo_win_a, elo_draw, elo_win_b = self.elo_model.predict(team_a, team_b, neutral)
        
        # Poisson prediction
        poisson_result = self.poisson_model.predict_scoreline(team_a, team_b, neutral)
        poisson_win_a = poisson_result["win_a"]
        poisson_draw = poisson_result["draw"]
        poisson_win_b = poisson_result["win_b"]
        
        # Feature-based prediction
        feat_win_a, feat_draw, feat_win_b = self.feature_model.predict(team_a, team_b, neutral)
        
        w = self.MODEL_WEIGHTS
        final_win_a = (
            elo_win_a * w["elo"] +
            poisson_win_a * w["poisson"] +
            feat_win_a * w["feature"]
        )
        final_draw = (
            elo_draw * w["elo"] +
            poisson_draw * w["poisson"] +
            feat_draw * w["feature"]
        )
        final_win_b = (
            elo_win_b * w["elo"] +
            poisson_win_b * w["poisson"] +
            feat_win_b * w["feature"]
        )
        
        # Normalize
        total = final_win_a + final_draw + final_win_b
        final_win_a /= total
        final_draw /= total
        final_win_b /= total
        
        # Expected goals
        mu_a, mu_b = self.poisson_model.expected_goals(team_a, team_b, neutral)
        
        # Confidence based on model agreement
        probs_a = [elo_win_a, poisson_win_a, feat_win_a]
        confidence = 1.0 - np.std(probs_a) * 2.0
        
        return {
            "home_win_prob": round(final_win_a, 4),
            "draw_prob": round(final_draw, 4),
            "away_win_prob": round(final_win_b, 4),
            "expected_goals_home": round(mu_a, 2),
            "expected_goals_away": round(mu_b, 2),
            "most_likely_score": poisson_result["most_likely_score"],
            "confidence": round(max(0.5, min(1.0, confidence)), 3),
            "model_breakdown": {
                "elo": {"win_a": round(elo_win_a, 3), "draw": round(elo_draw, 3), "win_b": round(elo_win_b, 3)},
                "poisson": {"win_a": round(poisson_win_a, 3), "draw": round(poisson_draw, 3), "win_b": round(poisson_win_b, 3)},
                "feature": {"win_a": round(feat_win_a, 3), "draw": round(feat_draw, 3), "win_b": round(feat_win_b, 3)},
            }
        }
    
    def simulate_knockout(
        self,
        team_a: TeamFeatures,
        team_b: TeamFeatures,
        neutral: bool = True
    ) -> Tuple[str, float]:
        """Simulate a knockout match (no draw)"""
        result = self.predict_match(team_a, team_b, neutral)
        win_a = result["home_win_prob"]
        win_b = result["away_win_prob"]
        
        # No draw in knockouts - redistribute
        total = win_a + win_b
        p_a = win_a / total
        
        if np.random.random() < p_a:
            return team_a.name, p_a
        else:
            return team_b.name, 1 - p_a
    
    def generate_explanation(
        self,
        team_a: TeamFeatures,
        team_b: TeamFeatures,
        result: Dict
    ) -> Dict:
        """Generate AI explanation for prediction"""
        factors = []
        
        if team_a.elo_rating > team_b.elo_rating:
            diff = team_a.elo_rating - team_b.elo_rating
            factors.append({
                "factor": "ELO Rating",
                "advantage": team_a.name,
                "value": f"+{diff:.0f} ELO points",
                "impact": "high" if diff > 100 else "medium",
                "icon": "⚡"
            })
        
        if team_a.fifa_ranking < team_b.fifa_ranking:
            factors.append({
                "factor": "FIFA Ranking",
                "advantage": team_a.name,
                "value": f"#{team_a.fifa_ranking} vs #{team_b.fifa_ranking}",
                "impact": "medium",
                "icon": "🏆"
            })
        
        if team_a.form_points > team_b.form_points + 2:
            factors.append({
                "factor": "Recent Form",
                "advantage": team_a.name,
                "value": f"{team_a.form_points} vs {team_b.form_points} pts (last 10)",
                "impact": "high",
                "icon": "🔥"
            })
        
        if team_a.xg_avg > team_b.xg_avg + 0.2:
            factors.append({
                "factor": "Attack Strength (xG)",
                "advantage": team_a.name,
                "value": f"{team_a.xg_avg:.2f} vs {team_b.xg_avg:.2f} xG/game",
                "impact": "high",
                "icon": "⚽"
            })
        
        if team_a.xga_avg < team_b.xga_avg - 0.2:
            factors.append({
                "factor": "Defensive Solidity (xGA)",
                "advantage": team_a.name,
                "value": f"{team_a.xga_avg:.2f} vs {team_b.xga_avg:.2f} xGA/game",
                "impact": "medium",
                "icon": "🛡️"
            })
        
        if team_a.squad_value_m > team_b.squad_value_m * 1.3:
            factors.append({
                "factor": "Squad Value",
                "advantage": team_a.name,
                "value": f"€{team_a.squad_value_m:.0f}M vs €{team_b.squad_value_m:.0f}M",
                "impact": "medium",
                "icon": "💎"
            })
        
        if team_a.wc_titles > team_b.wc_titles:
            factors.append({
                "factor": "World Cup Pedigree",
                "advantage": team_a.name,
                "value": f"{team_a.wc_titles} titles vs {team_b.wc_titles} titles",
                "impact": "low",
                "icon": "🌟"
            })
        
        if team_b.injured_key_players > team_a.injured_key_players:
            factors.append({
                "factor": "Squad Fitness",
                "advantage": team_a.name,
                "value": f"{team_b.injured_key_players} injuries for {team_b.name}",
                "impact": "medium",
                "icon": "🏥"
            })
        
        return {
            "favored_team": team_a.name if result["home_win_prob"] > result["away_win_prob"] else team_b.name,
            "win_probability": max(result["home_win_prob"], result["away_win_prob"]),
            "factors": factors[:6],  # Top 6 factors
            "summary": self._build_summary(team_a, team_b, result, factors)
        }
    
    def _build_summary(self, team_a, team_b, result, factors):
        favored = team_a.name if result["home_win_prob"] > result["away_win_prob"] else team_b.name
        prob = max(result["home_win_prob"], result["away_win_prob"])
        if prob > 0.65:
            strength = "strong favorites"
        elif prob > 0.55:
            strength = "slight favorites"
        else:
            strength = "evenly matched"
        return f"{favored} are {strength} with a {prob*100:.1f}% win probability. Key factors include {', '.join([f['factor'] for f in factors[:3]]) if factors else 'overall team quality'}."
