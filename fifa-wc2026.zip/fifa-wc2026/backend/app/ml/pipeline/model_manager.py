"""
Model Manager - loads team data, provides prediction interface
"""
import json
import logging
from typing import Dict, Optional
from app.ml.models.ensemble import EnsemblePredictor, TeamFeatures
from app.ml.pipeline.simulator import TournamentSimulator
from app.data.seed_data import QUALIFIED_TEAMS, PLAYERS_DATA

logger = logging.getLogger(__name__)


class ModelManager:
    def __init__(self):
        self.predictor = EnsemblePredictor()
        self.teams_cache: Dict[str, TeamFeatures] = {}
        self.simulation_cache: Optional[Dict] = None
        self.simulator: Optional[TournamentSimulator] = None
    
    async def load_models(self):
        """Initialize models and load team data"""
        logger.info("Loading team data and initializing models...")
        self._load_teams_from_seed()
        self.simulator = TournamentSimulator(self.teams_cache)
        logger.info(f"Loaded {len(self.teams_cache)} teams")
    
    def _load_teams_from_seed(self):
        for team_data in QUALIFIED_TEAMS:
            tf = TeamFeatures(
                name=team_data["name"],
                elo_rating=team_data["elo_rating"],
                fifa_ranking=team_data["fifa_ranking"],
                squad_value_m=team_data["squad_value_m"],
                goals_scored_avg=team_data["goals_scored_avg"],
                goals_conceded_avg=team_data["goals_conceded_avg"],
                xg_avg=team_data["xg_avg"],
                xga_avg=team_data["xga_avg"],
                possession_avg=team_data["possession_avg"],
                shots_on_target_avg=team_data["shots_on_target_avg"],
                clean_sheets_pct=team_data["clean_sheets_pct"],
                form_points=team_data["form_points"],
                wc_titles=team_data["wc_titles"],
                wc_appearances=team_data["wc_appearances"],
                manager_experience_years=team_data["manager_experience_years"],
                avg_age=team_data["avg_age"],
                home_advantage=team_data.get("home_advantage", 0.0),
            )
            self.teams_cache[team_data["name"]] = tf
    
    def get_team(self, name: str) -> Optional[TeamFeatures]:
        # Try exact match first
        if name in self.teams_cache:
            return self.teams_cache[name]
        # Try case-insensitive
        for k, v in self.teams_cache.items():
            if k.lower() == name.lower():
                return v
        return None
    
    def get_all_teams(self) -> Dict[str, TeamFeatures]:
        return self.teams_cache
    
    def predict_match(self, home_team: str, away_team: str, neutral: bool = True) -> Optional[Dict]:
        team_a = self.get_team(home_team)
        team_b = self.get_team(away_team)
        if not team_a or not team_b:
            return None
        result = self.predictor.predict_match(team_a, team_b, neutral)
        explanation = self.predictor.generate_explanation(team_a, team_b, result)
        result["explanation"] = explanation
        result["home_team"] = home_team
        result["away_team"] = away_team
        return result
    
    def run_tournament_simulation(self, n_simulations: int = 10000) -> Dict:
        if not self.simulator:
            self.simulator = TournamentSimulator(self.teams_cache)
        return self.simulator.run_simulations(n_simulations)
    
    def get_tournament_predictions(self) -> Dict:
        """Quick predictions using model strength, no full simulation"""
        results = {}
        teams = list(self.teams_cache.values())
        
        for team in teams:
            # Simplified probability based on ELO and features
            elo_score = (team.elo_rating - 1700) / 500
            form_score = (team.form_points - 10) / 20
            wc_score = team.wc_titles * 0.05 + team.wc_appearances * 0.005
            
            raw_score = elo_score * 0.5 + form_score * 0.3 + wc_score * 0.2
            results[team.name] = raw_score
        
        # Softmax to probabilities
        import math
        exp_scores = {k: math.exp(v * 3) for k, v in results.items()}
        total = sum(exp_scores.values())
        probs = {k: v / total for k, v in exp_scores.items()}
        
        return dict(sorted(probs.items(), key=lambda x: x[1], reverse=True))
    
    def get_players_for_team(self, team_name: str) -> list:
        return PLAYERS_DATA.get(team_name, [])
    
    def get_team_stats(self, team_name: str) -> Optional[Dict]:
        from app.data.seed_data import QUALIFIED_TEAMS
        for t in QUALIFIED_TEAMS:
            if t["name"].lower() == team_name.lower():
                return t
        return None
