"""
FIFA WC 2026 - Monte Carlo Tournament Simulator
48 teams, 12 groups of 4, full bracket simulation
"""

import numpy as np
import random
from typing import Dict, List, Tuple
from collections import defaultdict

from app.ml.models.ensemble import EnsemblePredictor, TeamFeatures


# WC 2026 Group Structure (12 groups A-L, 4 teams each = 48 teams)
WC2026_GROUPS = {
    "A": ["Argentina", "Morocco", "Australia", "Saudi Arabia"],
    "B": ["France", "Japan", "Iran", "Ghana"],
    "C": ["Spain", "Germany", "Colombia", "Senegal"],
    "D": ["England", "Netherlands", "USA", "Croatia"],
    "E": ["Brazil", "Belgium", "Uruguay", "Italy"],
    "F": ["Portugal", "Mexico", "Canada", "South Korea"],
    "G": ["Argentina", "Morocco", "Australia", "Saudi Arabia"],  # Placeholder
    "H": ["France", "Japan", "Iran", "Ghana"],
    "I": ["Spain", "Germany", "Colombia", "Senegal"],
    "J": ["England", "Netherlands", "USA", "Croatia"],
    "K": ["Brazil", "Belgium", "Uruguay", "Italy"],
    "L": ["Portugal", "Mexico", "Canada", "South Korea"],
}


class TournamentSimulator:
    def __init__(self, teams_data: Dict[str, TeamFeatures]):
        self.teams = teams_data
        self.predictor = EnsemblePredictor()
        
    def _simulate_group_match(
        self,
        team_a_name: str,
        team_b_name: str,
        neutral: bool = True
    ) -> Tuple[int, int]:
        """Simulate a single match, return (goals_a, goals_b)"""
        if team_a_name not in self.teams or team_b_name not in self.teams:
            return (1, 1)
        
        team_a = self.teams[team_a_name]
        team_b = self.teams[team_b_name]
        result = self.predictor.predict_match(team_a, team_b, neutral)
        
        mu_a = result["expected_goals_home"]
        mu_b = result["expected_goals_away"]
        
        goals_a = np.random.poisson(mu_a)
        goals_b = np.random.poisson(mu_b)
        return goals_a, goals_b
    
    def _simulate_group_stage(self, groups: Dict[str, List[str]]) -> Dict[str, List[str]]:
        """Simulate all group matches, return qualified teams per group"""
        group_qualifiers = {}
        
        for group_name, teams in groups.items():
            standings = {team: {"pts": 0, "gd": 0, "gf": 0} for team in teams}
            
            # Round-robin within group
            for i in range(len(teams)):
                for j in range(i + 1, len(teams)):
                    ta, tb = teams[i], teams[j]
                    ga, gb = self._simulate_group_match(ta, tb)
                    
                    standings[ta]["gf"] += ga
                    standings[tb]["gf"] += gb
                    standings[ta]["gd"] += ga - gb
                    standings[tb]["gd"] += gb - ga
                    
                    if ga > gb:
                        standings[ta]["pts"] += 3
                    elif ga == gb:
                        standings[ta]["pts"] += 1
                        standings[tb]["pts"] += 1
                    else:
                        standings[tb]["pts"] += 3
            
            # Sort by pts, then gd, then gf
            sorted_teams = sorted(
                teams,
                key=lambda t: (standings[t]["pts"], standings[t]["gd"], standings[t]["gf"]),
                reverse=True
            )
            group_qualifiers[group_name] = sorted_teams
        
        return group_qualifiers
    
    def _simulate_knockout_match(self, team_a_name: str, team_b_name: str) -> str:
        """Simulate knockout match (no draw), return winner name"""
        if team_a_name not in self.teams or team_b_name not in self.teams:
            return random.choice([team_a_name, team_b_name])
        
        team_a = self.teams[team_a_name]
        team_b = self.teams[team_b_name]
        result = self.predictor.predict_match(team_a, team_b, neutral=True)
        
        win_a = result["home_win_prob"]
        win_b = result["away_win_prob"]
        total = win_a + win_b
        
        return team_a_name if random.random() < (win_a / total) else team_b_name
    
    def simulate_tournament(self, groups: Dict[str, List[str]]) -> Dict[str, str]:
        """Simulate full tournament, return {team: stage_reached}"""
        results = {}
        
        # Group stage - top 2 from each group qualify + 8 best 3rd place
        group_qualifiers = self._simulate_group_stage(groups)
        
        # Get R32 teams (top 2 from each of 12 groups = 24, plus 8 best 3rd = 32)
        r32_teams = []
        third_place_teams = []
        
        for group_name, teams in group_qualifiers.items():
            results[teams[0]] = "R32"
            results[teams[1]] = "R32"
            results[teams[2]] = "3rd_place"
            results[teams[3]] = "group_stage"
            r32_teams.extend([teams[0], teams[1]])
            third_place_teams.append(teams[2])
        
        # Best 8 third-place teams advance
        random.shuffle(third_place_teams)
        advancing_third = third_place_teams[:8]
        for t in advancing_third:
            results[t] = "R32"
            r32_teams.append(t)
        
        # Knockout rounds
        random.shuffle(r32_teams)
        
        # Round of 32 (32 teams -> 16)
        r16_teams = []
        for i in range(0, len(r32_teams), 2):
            if i + 1 < len(r32_teams):
                winner = self._simulate_knockout_match(r32_teams[i], r32_teams[i+1])
                loser = r32_teams[i] if winner == r32_teams[i+1] else r32_teams[i+1]
                results[winner] = "R16"
                r16_teams.append(winner)
        
        # Round of 16 -> QF (8 teams)
        qf_teams = []
        for i in range(0, len(r16_teams), 2):
            if i + 1 < len(r16_teams):
                winner = self._simulate_knockout_match(r16_teams[i], r16_teams[i+1])
                results[winner] = "QF"
                qf_teams.append(winner)
        
        # Quarter-finals -> SF (4 teams)
        sf_teams = []
        for i in range(0, len(qf_teams), 2):
            if i + 1 < len(qf_teams):
                winner = self._simulate_knockout_match(qf_teams[i], qf_teams[i+1])
                results[winner] = "SF"
                sf_teams.append(winner)
        
        # Semi-finals -> Final (2 teams)
        finalists = []
        for i in range(0, len(sf_teams), 2):
            if i + 1 < len(sf_teams):
                winner = self._simulate_knockout_match(sf_teams[i], sf_teams[i+1])
                results[winner] = "FINAL"
                finalists.append(winner)
        
        # Final
        if len(finalists) >= 2:
            champion = self._simulate_knockout_match(finalists[0], finalists[1])
            results[champion] = "WINNER"
        
        return results
    
    def run_simulations(
        self,
        n_simulations: int = 10000,
        groups: Dict[str, List[str]] = None
    ) -> Dict:
        """Run N Monte Carlo simulations, aggregate results"""
        if groups is None:
            groups = WC2026_GROUPS
        
        all_teams = list(self.teams.keys())
        
        stage_counts = defaultdict(lambda: defaultdict(int))
        
        stage_order = ["group_stage", "3rd_place", "R32", "R16", "QF", "SF", "FINAL", "WINNER"]
        stage_weights = {"group_stage": 1, "3rd_place": 2, "R32": 3, "R16": 4, "QF": 5, "SF": 6, "FINAL": 7, "WINNER": 8}
        
        for sim_idx in range(n_simulations):
            sim_result = self.simulate_tournament(groups)
            for team, stage in sim_result.items():
                stage_counts[team][stage] += 1
                # Count all stages achieved
                sw = stage_weights.get(stage, 0)
                for s, w in stage_weights.items():
                    if w <= sw:
                        stage_counts[team][f"reached_{s}"] += 1
        
        # Compute probabilities
        final_results = {}
        for team in all_teams:
            counts = stage_counts.get(team, {})
            total = n_simulations
            
            final_results[team] = {
                "win_probability": round(counts.get("WINNER", 0) / total, 4),
                "final_probability": round(counts.get("reached_FINAL", 0) / total, 4),
                "semi_probability": round(counts.get("reached_SF", 0) / total, 4),
                "quarter_probability": round(counts.get("reached_QF", 0) / total, 4),
                "r16_probability": round(counts.get("reached_R16", 0) / total, 4),
                "group_qualification": round(counts.get("reached_R32", 0) / total, 4),
                "team_name": team,
            }
        
        # Sort by win probability
        sorted_results = dict(
            sorted(final_results.items(), key=lambda x: x[1]["win_probability"], reverse=True)
        )
        
        return {
            "n_simulations": n_simulations,
            "results": sorted_results,
            "top_5": list(sorted_results.keys())[:5],
        }
