from fastapi import APIRouter, Request
from app.data.seed_data import PLAYERS_DATA, QUALIFIED_TEAMS

# Players router
router = APIRouter()


@router.get("/")
async def get_all_players():
    all_players = []
    for team_name, players in PLAYERS_DATA.items():
        for p in players:
            all_players.append({**p, "team": team_name})
    return {"players": all_players, "total": len(all_players)}


@router.get("/team/{team_name}")
async def get_players_by_team(team_name: str):
    players = PLAYERS_DATA.get(team_name, [])
    return {"team": team_name, "players": players}
