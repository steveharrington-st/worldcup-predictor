from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Optional

router = APIRouter()


class MatchPredictionRequest(BaseModel):
    home_team: str
    away_team: str
    neutral: bool = True


@router.post("/match")
async def predict_match(request: Request, body: MatchPredictionRequest):
    mm = request.app.state.model_manager
    result = mm.predict_match(body.home_team, body.away_team, body.neutral)
    if not result:
        raise HTTPException(status_code=404, detail=f"Team not found: {body.home_team} or {body.away_team}")
    return result


@router.get("/tournament")
async def get_tournament_predictions(request: Request):
    mm = request.app.state.model_manager
    probs = mm.get_tournament_predictions()
    
    teams_data = mm.get_all_teams()
    result = []
    for rank, (team_name, prob) in enumerate(probs.items(), 1):
        team = teams_data.get(team_name)
        if team:
            result.append({
                "rank": rank,
                "team": team_name,
                "win_probability": round(prob * 100, 2),
                "elo_rating": team.elo_rating,
                "fifa_ranking": team.fifa_ranking,
                "squad_value_m": team.squad_value_m,
                "form_points": team.form_points,
                "wc_titles": team.wc_titles,
            })
    return {"predictions": result}


@router.get("/teams")
async def get_all_team_names(request: Request):
    mm = request.app.state.model_manager
    teams = mm.get_all_teams()
    return {"teams": sorted(list(teams.keys()))}
