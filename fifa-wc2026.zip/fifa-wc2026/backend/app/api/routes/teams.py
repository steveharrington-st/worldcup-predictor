from fastapi import APIRouter, HTTPException, Request
from app.data.seed_data import QUALIFIED_TEAMS, PLAYERS_DATA

router = APIRouter()


@router.get("/")
async def get_all_teams(request: Request):
    return {"teams": QUALIFIED_TEAMS}


@router.get("/{team_name}")
async def get_team(team_name: str, request: Request):
    mm = request.app.state.model_manager
    stats = mm.get_team_stats(team_name)
    if not stats:
        raise HTTPException(status_code=404, detail=f"Team {team_name} not found")
    
    players = mm.get_players_for_team(team_name)
    
    return {
        "team": stats,
        "players": players,
        "player_count": len(players),
    }


@router.get("/{team_name}/form")
async def get_team_form(team_name: str, request: Request):
    mm = request.app.state.model_manager
    team = mm.get_team(team_name)
    if not team:
        raise HTTPException(status_code=404, detail=f"Team {team_name} not found")
    
    # Simulated form data (last 10 matches)
    import random
    random.seed(hash(team_name))
    
    form_results = []
    for i in range(10):
        r = random.random()
        if r < team.form_points / 30:
            result = "W"
        elif r < team.form_points / 20:
            result = "D"
        else:
            result = "L"
        form_results.append(result)
    
    return {
        "team": team_name,
        "form": form_results,
        "form_string": "".join(form_results),
        "points": team.form_points,
    }
