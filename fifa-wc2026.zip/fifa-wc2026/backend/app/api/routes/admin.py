from app.api.routes.analytics_admin import admin_router as router
