from fastapi import APIRouter, HTTPException, Request, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
import asyncio

router = APIRouter()

_simulation_cache = {}


class SimulationRequest(BaseModel):
    n_simulations: int = 10000


@router.post("/simulate")
async def run_simulation(request: Request, body: SimulationRequest):
    n = body.n_simulations
    if n > 100000:
        raise HTTPException(status_code=400, detail="Max 100,000 simulations")
    if n < 100:
        raise HTTPException(status_code=400, detail="Min 100 simulations")
    
    mm = request.app.state.model_manager
    
    # Run in thread pool to avoid blocking
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, mm.run_tournament_simulation, n)
    
    return result


@router.get("/standings")
async def get_standings(request: Request):
    """Get current group standings prediction"""
    mm = request.app.state.model_manager
    teams = mm.get_all_teams()
    
    from app.ml.pipeline.simulator import WC2026_GROUPS
    
    groups = {}
    for group_name in ["A", "B", "C", "D", "E", "F"]:
        if group_name in WC2026_GROUPS:
            group_teams = WC2026_GROUPS[group_name]
            group_data = []
            for t_name in group_teams:
                team = teams.get(t_name)
                if team:
                    group_data.append({
                        "team": t_name,
                        "elo": team.elo_rating,
                        "ranking": team.fifa_ranking,
                        "form": team.form_points,
                    })
            groups[group_name] = group_data
    
    return {"groups": groups}


@router.get("/groups")
async def get_groups(request: Request):
    from app.ml.pipeline.simulator import WC2026_GROUPS
    from app.data.seed_data import QUALIFIED_TEAMS
    
    mm = request.app.state.model_manager
    teams_map = {t["name"]: t for t in QUALIFIED_TEAMS}
    
    result = {}
    for group, teams in WC2026_GROUPS.items():
        if group in ["G", "H", "I", "J", "K", "L"]:
            continue  # Skip duplicates
        result[group] = []
        for team_name in teams:
            if team_name in teams_map:
                t = teams_map[team_name]
                result[group].append({
                    "name": team_name,
                    "code": t["code"],
                    "confederation": t["confederation"],
                    "fifa_ranking": t["fifa_ranking"],
                    "elo_rating": t["elo_rating"],
                })
    
    return {"groups": result}
