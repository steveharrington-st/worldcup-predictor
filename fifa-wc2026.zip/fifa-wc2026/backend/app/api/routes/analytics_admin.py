from fastapi import APIRouter, Request
from app.data.seed_data import QUALIFIED_TEAMS

analytics_router = APIRouter()
admin_router = APIRouter()


@analytics_router.get("/rankings")
async def get_rankings():
    sorted_teams = sorted(QUALIFIED_TEAMS, key=lambda t: t["fifa_ranking"])
    return {"rankings": [
        {"rank": i+1, "team": t["name"], "code": t["code"],
         "elo": t["elo_rating"], "fifa_rank": t["fifa_ranking"],
         "value": t["squad_value_m"], "confederation": t["confederation"]}
        for i, t in enumerate(sorted_teams)
    ]}


@analytics_router.get("/comparison/{team_a}/{team_b}")
async def compare_teams(team_a: str, team_b: str):
    teams_map = {t["name"]: t for t in QUALIFIED_TEAMS}
    ta = teams_map.get(team_a)
    tb = teams_map.get(team_b)
    if not ta or not tb:
        return {"error": "Team not found"}
    
    metrics = ["elo_rating", "squad_value_m", "xg_avg", "xga_avg",
               "possession_avg", "clean_sheets_pct", "form_points"]
    
    comparison = {}
    for m in metrics:
        comparison[m] = {
            "team_a": ta.get(m, 0),
            "team_b": tb.get(m, 0),
        }
    
    return {
        "team_a": team_a,
        "team_b": team_b,
        "comparison": comparison,
    }


@analytics_router.get("/top-stats")
async def get_top_stats():
    top_elo = sorted(QUALIFIED_TEAMS, key=lambda t: t["elo_rating"], reverse=True)[:10]
    top_value = sorted(QUALIFIED_TEAMS, key=lambda t: t["squad_value_m"], reverse=True)[:10]
    top_xg = sorted(QUALIFIED_TEAMS, key=lambda t: t["xg_avg"], reverse=True)[:10]
    
    return {
        "top_elo": [{"team": t["name"], "value": t["elo_rating"]} for t in top_elo],
        "top_value": [{"team": t["name"], "value": t["squad_value_m"]} for t in top_value],
        "top_xg": [{"team": t["name"], "value": t["xg_avg"]} for t in top_xg],
    }


@admin_router.get("/status")
async def admin_status(request: Request):
    mm = request.app.state.model_manager
    return {
        "status": "operational",
        "teams_loaded": len(mm.get_all_teams()),
        "models": ["ELO", "Poisson", "Ensemble Feature Model"],
        "version": "1.0.0",
    }


@admin_router.post("/refresh")
async def refresh_data(request: Request):
    mm = request.app.state.model_manager
    mm._load_teams_from_seed()
    return {"status": "refreshed", "teams": len(mm.get_all_teams())}
