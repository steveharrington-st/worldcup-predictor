from app.api.routes.analytics_admin import analytics_router as router
