# ⚽ FIFA World Cup 2026 AI Prediction Platform

A production-ready AI-powered football analytics platform predicting the FIFA World Cup 2026 winner using machine learning, ELO ratings, Poisson models, and Monte Carlo simulation.

## 🚀 Quick Start (Windows)

### Step 1 — Install Prerequisites
1. **Python 3.11+**: https://python.org/downloads → check "Add Python to PATH"
2. **Node.js 20 LTS**: https://nodejs.org

### Step 2 — Start Backend
Open Command Prompt and run:
```
cd fifa-wc2026\backend
python -m venv venv
venv\Scripts\activate
pip install fastapi uvicorn pydantic pydantic-settings numpy scipy sqlalchemy aiofiles
uvicorn app.main:app --reload --port 8000
```

### Step 3 — Start Frontend
Open a NEW Command Prompt window:
```
cd fifa-wc2026\frontend
npm install
npm run dev
```

### Step 4 — Open Browser
Go to: **http://localhost:3000**

---

## 🌐 Pages

| Page | URL | Description |
|------|-----|-------------|
| Home | `/` | Tournament predictions for all 48 teams |
| Match Predictor | `/match-predictor` | Head-to-head AI predictions |
| Simulator | `/simulator` | Monte Carlo tournament simulator |
| Teams | `/teams` | Browse all qualified nations |
| Team Detail | `/teams/Argentina` | Individual team stats & players |
| Analytics | `/analytics` | Charts, ELO, xG, squad values |
| Admin | `/admin` | System management |
| API Docs | `http://localhost:8000/docs` | Backend Swagger UI |

## 🤖 ML Models Used
- **ELO Rating Model** — head-to-head strength estimation
- **Dixon-Coles Poisson Model** — expected goals & scoreline prediction  
- **Ensemble Feature Model** — weighted combination of 8+ features
- **Monte Carlo Simulator** — 1K/10K/100K tournament simulations

## 🐳 Docker (Optional)
```
docker-compose up --build
```

## 📁 Project Structure
```
fifa-wc2026/
├── backend/
│   ├── app/
│   │   ├── main.py          # FastAPI app
│   │   ├── api/routes/      # API endpoints
│   │   ├── ml/models/       # ML prediction engines
│   │   ├── ml/pipeline/     # Simulator & model manager
│   │   ├── db/              # Database models
│   │   ├── data/            # Seed data (48 teams)
│   │   └── core/            # Config
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── app/             # Next.js pages
│   │   ├── components/      # React components
│   │   └── lib/             # API client & utilities
│   ├── package.json
│   └── tailwind.config.js
└── docker-compose.yml
```
